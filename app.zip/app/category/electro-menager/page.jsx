import ClientComponentElectroMenager from "./clientComponentElectroMenager"

export const metadata = {
    title: "Appareils électro-ménager | Maison et Bureau",
    description: "Vente et achat appareils et accésoires électro-ménager de qualité au Cameroun",
    keywords: "Fer à repasser, robot mixeur, moulinex, moulin à épice, chauffe-eau électrique, extracteur de jus scéleuse électrique Hachoir à viande et légume, Hacheuse de viande "
}

export default function AllElectroMenagerProducts () {
    return(
        <>
        <ClientComponentElectroMenager/>

        <div>
            
        </div>
        </>
    )
}
 
