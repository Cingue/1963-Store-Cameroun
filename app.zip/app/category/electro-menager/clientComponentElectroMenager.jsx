'use client'

import { electroMenagerData } from "@/app/components/Utils/electroMenagerData";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ClientComponentElectroMenager () {

    const [showCategory, setShowCategoy] = useState(true)
    const router = useRouter()
    const { cuisine } = electroMenagerData

    return ( 

       
        <>
        <Image src='/favicones/menu.svg' width={45} height={45} alt="menu" className="fixed" onClick={() => setShowCategoy(!showCategory)}/> 

        <div className="fixed top-40 h-full left-0 flex flex-col gap-4 shadow-lg border-l border-l-gray-700 overflow-auto z-10 bg-white" style={{minWidth: '150px', paddingTop: '3.5rem', backgroundColor: 'white', paddingLeft: '.3em', paddingRight: '.3rem', display: showCategory ? 'none': 'block', lineHeight: '3rem'}}>
            
                <Image src='/favicones/close_icon.svg' width={25} height={25} alt="close-icone" style={{marginLeft: "9rem", paddingTop: '2rem'}} onClick={() => setShowCategoy(!showCategory)}/>

                <Link href="/category/electro-menager/cuisine" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/cuisine.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Cuisine</Link>

        </div>

        <div style={{padding: showCategory ? "3rem 1rem 1rem 3rem" : "3rem 1rem 1rem 2rem" }}>

        <div style={{padding: "0rem 1rem 1rem 1rem"}} className="flex items-center flex-col gap-4">
        <h1 className="font-bold">Ustensiles cuisines</h1>
                <div className="category-container">
                    {cuisine && cuisine.map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 16)}...</p>
                                <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                                <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                            </div>
                        </Link>    
    
                            </div> 
                    )).slice(0,4)}
                </div>
                <button style={{backgroundColor: "#111184", padding: ".3em", borderRadius: ".5em"}} className="text-white self-center" onClick={() => router.push("/category/electro-menager/cuisine")}>Voir plus...</button>

            </div>
        </div>
        </>
     );
}