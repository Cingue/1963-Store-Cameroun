import Link from "next/link";
import Image from "next/image";
import ClientComponentCuisine from "./clientComponentCuisine";

export const metadata = {
    title: "Accessoires Electro-Menager",
    description: "Achat et vente accessoires electro-menager au Cameroun",
    keywords: "robots mixeur, moulinex, fer a repasser, chauffe eau",
}


export default function AllCuisineProducts () {
    return(
        <>
        <ClientComponentCuisine />

        <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </>
    )
}
 
