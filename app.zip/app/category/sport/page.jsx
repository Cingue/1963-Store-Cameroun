import ClientComponentSport from "./clientComponentSport"

export const metadata = {
    title: "Vente maillots club | Survêtements | Equipements Sport",
    description: "Vente et achat Survêtement et ensemble maillot et équipements sport",
    keywords: "Maillots, Survêtement equipements sport" 
}


export default function AllSportProducts () {
    return(
        <>
        <ClientComponentSport/>
        <div className="flex flex-col item-center justify-center bg-white" style={{padding: '1rem'}}>
                    <h1>Acheter vos <strong>Maillots de club (Real de madrid, Barcelone, Manchester united, Manchester City, Brighton, Marseille, Paris saint Germain et bien d'autres...)</strong> et vos <strong>Survêtements</strong> au <strong>Cameroun, dans les villes de Douala et Yaounde</strong> : faites le bon choix sur votre <strong>site de vente en ligne 1963-store.com</strong> </h1>

                   <div className="gap-4 flex flex-col">
                    <h2 className="text-justify">Chez 1963-store.com, nous savons que le sport est bien plus qu'une simple activité : c'est un mode de vie, une passion, et une source d'inspiration. C'est pourquoi nous avons sélectionné pour vous une large gamme de produits dédiés à la pratique sportive (maillots de vos clubs preféré, survetements etc...), alliant qualité, confort et style.</h2>

                    <ul>
                    Que vous soyez un athlète confirmé ou un amateur cherchant à améliorer ses performances et son style sportif, notre catégorie sport avec la <strong>Vente et achat des maillots de clubs</strong>vous offre tout ce dont vous avez besoin :

                    <li>
                    Vêtements techniques : <strong>maillots de club</strong>, <strong>shorts</strong>, <strong>Survêtements </strong> <strong> joggins</strong> conçus avec des matériaux respirants et légers pour un confort optimal.
                    </li>

                    <li>
                    Chaussures de sport : Découvrez nos modèles adaptés à chaque discipline : running, fitness, football, ou randonnée.
                    </li>

                    <li className="text-justify" >
                    Accessoires indispensables : <strong>sacs</strong>, gourdes et bien plus encore pour compléter votre <strong>équipement sportif</strong>. Tous nos produits sont sélectionnés pour répondre aux attentes des sportifs modernes, à la recherche de qualité et de durabilité.
                    </li>

                    </ul>

                    <h3>
                    Pourquoi acheter un maillot de club ou un Survêtement chez 1963-store.com pour vos besoins sportifs ?
                    </h3>

                    <ul>
                        <li>
                        Des marques de référence : Nous disposnons des maillots de vos équipes preféré pour vous garantir des produits qui répondent à vos besoins.
                        </li>

                        <li>
                        Une expérience client premium : Livraison rapide, retours faciles et un service client à votre écoute
                        </li>

                        <li>
                        Des prix compétitifs : Profitez d’offres exclusives et de promotions régulières pour équiper votre passion sans vous ruiner.
                        </li>
                    </ul>

                    <p  className="text-justify">
                    nous croyons que chaque sportif a le potentiel de se dépasser. C'est pourquoi nous mettons à votre disposition des produits de qualité, adaptés à chaque niveau et discipline. Peu importe vos objectifs – battre votre record personnel, exceller en compétition ou simplement rester actif – nous sommes là pour vous accompagner. Parcourez dès maintenant notre sélection sportive et préparez-vous à relever vos défis avec style et performance. Rejoignez la communauté 1963-store.com et faites passer votre passion au niveau supérieur. Découvrez nos collections dès aujourd'hui Explorer notre catégorie sport et trouvez tout ce qu'il vous faut pour vous équiper comme un pro ! 1963-store.com : Votre allié sport et performance.
                    </p>
                   </div>
                </div>
        </>
    )
}
 
