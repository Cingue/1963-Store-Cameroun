import ClientComponentMaillots from "./clientComponentMaillots"

export const metadata = {
    title: "Boutique vente et achat des Maillots Club Douala Cameroun",
    description: "Vente et achat maillots de vos club préférés dans la ville de douala et au cameroun. Maillot domicile et extérieure des vos équipes. Maillots Real Madrid, FC Barcelone, Manchester United, Manchester City, Barcelone, Liverpool, Brighton, Marseille, Paris saint Germain etc...",
    keywords: "Maillots, Survêtement" 
}

export default function AllMaillotsProducts () {
    return(
        <>
        <ClientComponentMaillots/>
        </>
    )
}
 
