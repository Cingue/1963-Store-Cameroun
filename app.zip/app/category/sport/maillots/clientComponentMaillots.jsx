'use client'

import { sportData } from "@/app/components/Utils/sportData";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function ClientComponentMaillots () {

    const shuffledArray = (array) => {
        for (let i = array.length -1; i > 0; i-- ) {
          const j = Math.floor(Math.random() * (i + 1))
          const temp = array[i]
          array[i] =  array[j]
          array[j] = temp
        }
    
        return array
      };

     const [showCategory, setShowCategoy] = useState(true)

     const { maillots, maillot_club } = sportData

    return ( 

        <>
        <Image src='/favicones/menu.svg' width={45} height={45} alt="menu" className="fixed" onClick={() => setShowCategoy(!showCategory)}/> 

         <div className="fixed top-40 h-full left-0 flex flex-col gap-4 shadow-lg border-l border-l-gray-700 overflow-auto z-30 bg-white" style={{minWidth: '150px', paddingTop: '3rem', backgroundColor: 'white', paddingLeft: '.3em', display: showCategory ? 'none': 'block', lineHeight: '3rem'}}>

                <Image src='/favicones/close_icon.svg' width={25} height={25} alt="close-icone" style={{marginLeft: "7rem", marginTop: '1.5rem'}} onClick={() => setShowCategoy(!showCategory)}/>

                <Link href="/category/sport/survetements" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/survet.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Survêtement </Link>
                
                <Link href="#" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/maillot.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Maillots</Link>
        </div>

        <div style={{padding: showCategory ? '0rem 1rem 1rem 2.8rem' : "0rem 1rem 1rem 4rem", width: '100%'}} className="gap-4 flex-flex-col items-center">

            <div className="flex flex-col items-center gap-4">
                <h1 className="font-bold text-lg">Mailots sport </h1>
                <div className="category-container">
                    {shuffledArray(maillot_club) && shuffledArray(maillot_club).map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 14)}...</p>
                                <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                                <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                            </div>
                        </Link>    
    
                            </div>
                    ))}
                </div>

            </div>

            <div className="flex flex-col items-center gap-4">
                <h1 className="font-bold text-lg">Mailots sport </h1>
                <div className="category-container">
                    {maillots && maillots.map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 14)}...</p>
                                <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                                <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                            </div>
                        </Link>    
    
                            </div>
                    ))}
                </div>

            </div>
              <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
            </Link> 
        </div>

        </>
     );
}