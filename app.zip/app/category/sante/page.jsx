import ClientComponentBienEtre from "./bien-etre/clientComponentBienEtre"


export const metadata = {
    title: "Vente et achat produits de santé",
    description: "Vente et achat produits et appareils santé au Cameroun",
    keywords: "Kopivitamine, bonbon hercule candy, vitamax double shot, kingsman, madu vitamine",
}

export default function AllClothProducts () {
    return(
        <>
        <ClientComponentBienEtre />

        <div className="flex flex-col item-center justify-center bg-white" style={{padding: '1rem'}}>

            <h2>Prenez soin de votre <strong>santé</strong> au quotidien</h2>

            <p className="text-justify">Sur <strong>1963-store.com</strong>, nous savons que chaque personne a des besoins uniques en matière de santé. C’est pourquoi nous vous offrons une sélection variée de produits soigneusement choisis pour prendre soin de votre corps, de votre esprit et atteindre votre objectif santé. Que vous recherchiez des <strong>compléments alimentaires</strong> pour renforcer votre immunité, des produits naturels et appareils pour mesurer et soulager les tensions, améliorer votre digestion, réduire le stress ou simplement maintenir un équilibre global, notre boutique en ligne est là pour vous accompagner. 
            </p>

            <p className="text-justify">Parce que la santé ne se limite pas à l’intérieur du corps, nous proposons également des huiles essentielles apaisantes, des produits bio et des accessoires pour améliorer votre bien-être global. Grâce à nos choix rigoureux des marques reconnues pour leur efficacité et leur engagement envers les ingrédients de qualité, vous pouvez mettre en place sans risques ni dangers une routine quotidienne qui favorise votre vitalité et vous aide à vous sentir mieux chaque jour.</p>

            <p className="text-justify">1963-store.com est bien plus qu’une boutique en ligne : c’est un espace où vous pouvez trouver des conseils pratiques, des recommandations personnalisées et des produits fiables. Nos équipes travaillent avec des marques renommées qui respectent des normes élevées en matière de qualité et de naturalité. Nous croyons fermement qu’investir dans votre santé est la meilleure décision que vous puissiez prendre, et nous sommes là pour vous y aider.
            </p>

            <p className="text-justify">Prenez soin de vous dès aujourd'hui avec des produits fiables et une sélection qui allie performance et naturalité. Sur 1963-store.com, votre santé est notre priorité, et nous faisons en sorte de vous accompagner dans votre quête d’un mode de vie sain et équilibré avec des solutions fiables, des produits de qualité et un service irréprochable, nous vous aidons à vivre mieux, chaque jour.</p>
        </div>
        </>
    )
}
 
