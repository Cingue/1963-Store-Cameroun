import ClientComponentBeauty from "./clientComponentBeauty"

export const metadata = {
    title: "Vente et achat produits de beauté | Cosmétique",
    description: "vente et achat produits cosmétique authentiques pour soins du corps",
    keywords: "Cosmétique, produits de beauté, produits maquillage, produits capillaire, savon de beauté, crème corporelle, soins intimes, gel de douche"
}

export default function AllBeautyProducts () {
    return(
        <>
        <ClientComponentBeauty />

        <div style={{padding: '1rem'}} className="bg-white">
            <p><strong>1963-store.com</strong> : la boutique en ligne dédiée à votre beauté
            Sur 1963-store.com, nous vous proposons une gamme complète de <strong>produits de beauté</strong> sélectionnés avec soin pour répondre à tous vos besoins. En parcourant votre boutique en ligne, vous allez découvrir des <strong>crèmes hydratantes</strong>, des <strong>produits pour les cheveux,</strong>, des parfums pour hommes et femmes (<strong>mousuf</strong>)  des sérums anti-âges, du maquillage de qualité professionnelle et des soins pour tous les types de peau. Pour vos besoins en beauté et bien-être, faites confiance à 1963-store.com le nouveau leader de la vente en ligne au Cameroun !</p>
        </div>
        </>
    )
}

