'use client'

import { beautyData } from "@/app/components/Utils/beautyData";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function ClientComponentSkin () {

    const [showCategory, setShowCategoy] = useState(true)

    const { skin } = beautyData

    return ( 
        <>
        <Image src='/favicones/menu.svg' width={45} height={45} alt="menu" className="fixed" onClick={() => setShowCategoy(!showCategory)}/> 

        <div className="fixed top-40 h-full left-0 flex flex-col gap-4 shadow-lg border-l border-l-gray-700 overflow-auto z-10 bg-white" style={{minWidth: '150px', paddingTop: '4rem', backgroundColor: 'white', paddingLeft: '.3em', paddingRight: '.3rem', display: showCategory ? 'none': 'block', lineHeight: '3rem'}}>

                <Image src='/favicones/close_icon.svg' width={25} height={25} alt="close-icone" style={{marginLeft: "7rem"}} onClick={() => setShowCategoy(!showCategory)}/>

                <Link href="#" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/skin.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Skin</Link>

                <Link href="/category/beauty/parfums" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/parfum.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Parfums</Link>
        </div>

        <div style={{padding: "3rem 1rem 1rem 1rem"}} className="flex items-center flex-col gap-4">
            <h1 className="font-bold tex-lg">PRODUITS DE BEAUTÉ</h1>
            <div>
                <div className={`${showCategory ? "category-container": 'category-container'}`} style={{paddingLeft: showCategory ? '2rem': '3rem'}}>
                    {skin && skin.map(item => (
                        <div className="div-anim" key={item.id}>
                    <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                        <div className="flex flex-col items-center" >
                            <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                            <p>{item.name}</p>
                            <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                            <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                        </div>
                    </Link>    

                        </div>
                    ))}
                </div>

            </div>
            
            <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </div>
        </>
     );
}