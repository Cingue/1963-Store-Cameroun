import ClientComponentSkin from "./clientComponentSkin"

export const metadata = {
    title: "Vente Produits de Beauté",
    description: "Achat et vente des produits de beauté homme/femme au Cameroun",
    keywords: "creme, parfums, gommage, cosmétique",
}


export default function AllSkinProducts () {
    return(
        <>
        <ClientComponentSkin />
        </>
    )
}
 
