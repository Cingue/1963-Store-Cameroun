'use client'

export default function ErrorBoundary({error}) {
    return <div className="flex flex-col items-center justify-center gap-4 p-4 text-4xl"  style={{minHeight: '100vh'}}> {error.message} </div>
}