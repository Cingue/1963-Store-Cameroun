import ClientComponentParfums from "./clientComponentParfums"

export const metadata = {
    title: "Boutique vente de Parfums d'origine à Douala ",
    description: "Acheter vos parfums de marque authentiques et haut de gamme de chez Bleu de channel, Jean Paul Gautier, Hugo Boss, Valentino, Versace, Calvin Klein, Lacoste... dans la ville de Douala, Yaounde et partout au cameroun. Acheter également les parfums mousuf à bon prix et gagnez confiance en vous durant toute la journée.",
    keywords: "creme, parfums, parfum moussuf  gommage, cosmétique",
}


export default function AllParfumsProducts () {
    return(
        <>
        <ClientComponentParfums />
        </>
    )
}
 
