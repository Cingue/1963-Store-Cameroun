import MontreDeLuxe from "@/app/components/GlobalProducts/MontreDeLuxe/MontresDeLuxe";
import { montresLuxeData } from "@/app/components/Utils/montresLuxe";
import Image from "next/image";
import Link from "next/link";

export const metadata = {
    title: "Montres de luxe Haut de Gamme Cameroun",
    description: "boutique de vente montres de luxe hommes et femmes, haut de gammer olex, audemar, casio, cartier etc. a Douala, Yaoundé",
    keywords: "",
}

export default function AllMontresDeLuxeProducts () {

    const { otherLuxe } = montresLuxeData

    
    const shuffledArray = (array) => {
        for (let i = array.length -1; i > 0; i-- ) {
          const j = Math.floor(Math.random() * (i + 1))
          const temp = array[i]
          array[i] =  array[j]
          array[j] = temp
        }
    
        return array
      };


    return(
        <>
        <meta property="product:condition" content="new" /> 
        <meta property="product:avaibility" content="In Stock" /> 
        <meta property="og:image" content="/bijoux_jpg/montres_breitling/breitling_chronomat_steel_black1.jpg" /> 
        <meta property="og:image" content="/bijoux/montres_cartier/cartier_201_1.webp" /> 

        <div className="flex flex-col items-center gap-4 p-4">
        <MontreDeLuxe /> 
        
        <div className="category-container">
                    {otherLuxe && shuffledArray(otherLuxe).map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 16)}...</p>
                                <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                                <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                            </div>
                        </Link>    
                            </div>
                    ))}
                </div>

        </div>

        </>
    )
}