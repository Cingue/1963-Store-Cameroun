'use client'

import { montresLuxeData } from "@/app/components/Utils/montresLuxe";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function ClientComponentEmporioArmani () {

    const [showCategory, setShowCategoy] = useState(true)

    const { emporio } = montresLuxeData

    return ( 

       
        <>
        <Image src='/favicones/menu.svg' width={45} height={45} alt="menu" className="fixed" onClick={() => setShowCategoy(!showCategory)}/> 

        <div className="fixed top-40 h-full left-0 flex flex-col gap-4 shadow-lg border-l border-l-gray-700 overflow-auto z-10 bg-white" style={{minWidth: '150px', paddingTop: '4rem', backgroundColor: 'white', paddingLeft: '.3em', paddingRight: '.3rem', display: showCategory ? 'none': 'block', lineHeight: '3rem'}}>
        <Image src='/favicones/close_icon.svg' width={25} height={25} alt="close-icone" style={{marginLeft: "11rem"}} onClick={() => setShowCategoy(!showCategory)}/>
        
        <Link href="/category/mode/montres" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/watch.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Montres</Link>

        {/* <Link href="/" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/bague.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Bagues</Link> */}

        <Link href="/category/mode/chaines"className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/bijoux.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Chaines</Link>

        {/* <Link href="/" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/boucle.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Boucles</Link> */}

        <Link href="/category/mode/manchettes" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/chaine.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Manchettes</Link>

        <Link href="/category/mode/cloth" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/cloth.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Tenue Afritude</Link>

        </div>

        <div style={{padding: showCategory ? "3rem 1rem 1rem 3rem" : "3rem 1rem 1rem 3rem" }}>

        <div style={{padding: "0rem 1rem 1rem 1rem"}} className="flex items-center flex-col gap-4">
        <h1 className="font-bold text-lg">Montre haut de gamme Emporio Armani</h1>
                <div className="category-container">
                    {emporio && emporio.map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 16)}...</p>
                                <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                                <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                            </div>
                        </Link>    
                            </div>
                    ))}
                </div>

            </div>
        </div>
        </>
     );
}