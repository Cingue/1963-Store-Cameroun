import ClientComponentEmporioArmani from "./clientComponentEmporioArmani"

export const metadata = {
    title: "Montres Haut de Gamme Série Emporio Armani",
    description: "acheter vos Montres preférées de luxe de marque Emporio Armani chez 1963 store Cameroun et sublimez davantage votre style",
    keywords: ""
}

export default function allProductEmporioArmani () {
    return(
        <>
        <meta property="product:condition" content="new" /> 
        <meta property="product:avaibility" content="In Stock" /> 
        <meta property="og:image" content="/bijoux_jpg/montres_emporio/emporio_armani_montre_homme_ar14001.jpg" /> 
        <ClientComponentEmporioArmani/>
        </>
    )
}
 
