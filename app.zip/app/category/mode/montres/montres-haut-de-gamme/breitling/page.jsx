import ClientComponentbreitling from "./clientComponentbreitling"

export const metadata = {
    title: "Montres Haut de Gamme Série Breitling",
    description: "acheter vos Montres preférées de luxe de marque Breitling chez 1963 store Cameroun et sublimez davantage votre style",
    keywords: ""
}

export default function allProductCartier () {
    return(
        <>
        <meta property="product:condition" content="new" /> 
        <meta property="product:avaibility" content="In Stock" /> 
        <meta property="og:image" content="/bijoux_jpg/montres_breitling/breitling_transocean_chronograph1.jpg" /> 
        <ClientComponentbreitling/>
        </>
    )
}
 
