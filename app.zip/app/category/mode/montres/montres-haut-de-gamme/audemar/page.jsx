import ClientComponentAudemar from "./clientComponentAudemar"

export const metadata = {
    title: "Montres Haut de Gamme Série Audemars",
    description: "acheter vos Montres preférées de luxe de marque Audemars chez 1963 store Cameroun et sublimez davantage votre style",
    keywords: ""
}

export default function allProductAudemar () {
    return(
        <>
        <meta property="product:condition" content="new" /> 
        <meta property="product:avaibility" content="In Stock" /> 
        <meta property="og:image" content="/bijoux_jpg/montres_audemar/audemars_piguet_royal_oak_chronograph_panda_38mm1.jpg" /> 
        
        <ClientComponentAudemar/>
        </>
    )
}
 
