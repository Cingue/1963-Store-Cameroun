import { allData } from "@/app/components/Utils/allData";
import Link from "next/link";
import Image from "next/image";
import AddToCart from "@/app/components/AddToCartButton/AddToCart";
import PicturesDetails from "@/app/components/ProductDetailPage/ProductDetailPage";

export const generateMetadata = async ({params}) => {
    const allParams = await params
    const productId = await allParams.name

    return{
        title: productId,
        description: productId,
        keywords: null
    }
}

export default async function getSingleProduct({params}) {
  
  const allParams = (await params)
  const productId = await allParams.name
 
  const product = allData.products.find(value => value.path === productId)

        if (!product) {
        throw new Error('Ooops! Could not find the product')
      }


        return(
            <>
          <div className="flex flex-col p-4" >
                <div className="py-8">
                <Link className="flex" href="/category/mode/montres/montres-haut-de-gamme/audemar"> <Image src="/favicones/back.svg" width={25} height={25} alt="back-icon"/> Back to products</Link>
                </div>

                <h1 className="text-lg font-bold self-center">{product.name}</h1>
                <p className="text-lg font-bold self-center" style={{color: "red"}}>{product.price.toLocaleString('en-US')}FCFA</p>
          
                       <div className="grid md:grid-cols-4 md:gap-3">
          
                           <div className="md:col-span-2">
                              <PicturesDetails img1={product.image_jpg} img2={product.image2} img3={product.image3} img4={product.image4}/>
                           </div>
          
                           <div className="flex flex-col items-center">
                               <ul style={{lineHeight: "2.2rem"}}>
                                
                                   <hr className="my-3"/>
                                   <div className="flex flex-col gap-4" >

                                    <h1 >Spécificité de la montre <strong>{product.name}</strong></h1>

                                    <ul>

                                        <li>
                                            <a> {product.description1} </a>
                                        </li>

                                        <li >
                                            <a> {product.description2} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description3} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description4} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description5} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description6} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description7} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description8} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description9} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description10} </a>
                                        </li>

                                        <li className="font-bold">
                                            <a className="font-normal"> {product.description11} </a>
                                        </li>
                                    </ul>

                                    <hr className="my-3"/>

                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-4">
                                            <Image src="/favicones/deliveryc.svg" alt="delivery-icon" width={40} height={40} />
                                            <p className="font-bold">Livraison rapide en 3h</p>
                                        </div>

                                        <div className="flex items-center gap-4">
                                            <Image src="/favicones/argentc.svg" alt="delivery-icon" width={40} height={40} />
                                            <p className="font-bold">Payement à la livraison</p>
                                        </div>

                                        <div className="flex items-center gap-4">
                                            <Image src="/favicones/garantiec.svg" alt="delivery-icon" width={40} height={40} />
                                            <p className="font-bold">2 ans de garantie</p>
                                        </div>
                                    </div>

                                   </div>
                               </ul>
                           </div>
          
                           <div>
                               <div className="card p-5 flex flex-col">
                                   <div className="mb-2 flex justify-between">
                                       <div>
                                           Prix
                                       </div>
                                       <div>
                                           {product.price.toLocaleString('en-US')} FCFA
                                       </div>
                                   </div>

                                   <AddToCart product={product} redirect={true}/>

                                   <div className="flex items-center justify-center">
                                   <a href="/cart" style={{marginTop: '1rem', padding: '.5rem', backgroundColor: 'orange', borderRadius: '.4rem'}} className="self-center">Allez au pannier</a>
                                   </div>
          
                           </div>
                       </div>

                   </div>
                               </div>

                                    <div className="flex flex-col gap-1 p-4 bg-white">
                                    <h1 className="text-justify"><strong>{product.description1.title1}</strong></h1>
                                    <p className="text-justify">{product.description1.content1}</p>

                                    <h2 className="text-justify"><strong>{product.description1.title2}</strong></h2>
                                    <p className="text-justify">{product.description1.content2}</p>

                                    <h2 className="text-justify"><strong>{product.description1.title3}</strong></h2>
                                    <p className="text-justify">{product.description1.content3}</p>

                                    <h2 className="text-justify"><strong>{product.description1.title4}</strong></h2>
                                    <p className="text-justify">{product.description1.content4}</p>
                                </div>

                   </>
   )
}

