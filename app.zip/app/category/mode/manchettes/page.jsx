import Link from "next/link"
import ClientComponentManchettes from "./clientComponentManchettes";
import Image from "next/image";

export const metadata = {
    title: "Manchettes pour chemise à bon prix Cameroun",
    description: "Achat et vente des bijoux hommes et femmes au Cameroun",
    keywords: "manchettes chemise homme/femme",
}


export default function AllManchettesProducts () {
    return(
        <>
        <meta property="product:amount" content="7500" /> 
        <meta property="product:condition" content="new" /> 
        <meta property="product:avaibility" content="In Stock" /> 
        <meta property="og:image" content="/manchette/manchette_cartier_argent.webp" /> 
        <ClientComponentManchettes />

        <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </>
    )
}
 
