import AllProducts from "./clientComponentMode"

export const metadata = {
    title: "Mode et Accessoire pour tous | Montres et bijoux",
    description: "boutique de vente bijoux hommes et femmes, montres de luxe rolex, audemar, casio, cartier manchettes au Cameroun: Douala, Yaoundé",
    keywords: "Montres connectées, Montre Rolex, Montre Cartier, Montre Omega, Montre Tissot, Montre Michael Kors, Montre casio, Chaines, Bracelets, boucles",
}

export default function AllModeProducts () {
    return(
        <>
        < AllProducts />
        <div className="flex flex-col item-center justify-center bg-white" style={{padding: '1rem'}}>

                    <h1 className="text-justify"><strong>Vente et achat Montres de luxe rolex, audemar cartier</strong> et <strong>Bijoux</strong>  de Luxe au <strong>Cameroun</strong> : faites le bon choix des montres et bijoux sur votre de <strong>site de vente en ligne 1963-store.com</strong> </h1>

                   <div className="gap-4 flex flex-col">
                    <p className="text-justify">Être bien habillé ne se résume pas à choisir les bonnes pièces, mais à se sentir bien dans son look. Que ce soit pour une occasion spéciale ou pour affirmer votre style au quotidien, une belle <strong>tenue afritude</strong>, <strong>une chaussure de marque, une paire de babouche, des boucles d'oreilles raffinées</strong>  ou un vêtement tendance peut transformer votre présence et captiver l’attention.</p>

                    <p className="text-justify">Sur <strong>1963-store Cameroun,</strong>  nous avons réuni pour vous une gamme variée de <strong>vêtements, chaussures et accessoires pour hommes, femmes et enfants, à des prix compétitifs.</strong> <strong>Des sous-vêtements </strong> confortables aux tenues de soirée élégantes, chaque produit a été soigneusement sélectionné pour répondre à vos besoins, tout en vous offrant un excellent rapport qualité-prix. Découvrez notre sélection <strong>Montre Rolex ,Cartier, Omega, Casio, Tissot, Audemars piguet, Michael Kors </strong> et habillez-vous en toute confiance pour toutes les occasions</p>

                    <p className="text-justify">Envie d'ajouter une touche d'élégance à votre look ? 1963-store.com Cameroun vous propose une large sélection de <strong> montres et bijoux de qualité</strong>, adaptés à tous les styles et à toutes les occasions. Que vous cherchiez une montre tendance, un bijou discret ou un accessoire sophistiqué, notre collection saura répondre à vos attentes.</p>

                    <p className="text-justify">Parcourez notre catégorie <strong>mode</strong>  sur <strong>1963-store.com Cameroun</strong> et découvrez des articles tels que  <strong>les montres, les bagues, les manchettes, les chaines, les tenues afritudes</strong>  qui feront briller votre style. Avec une livraison rapide partout au Cameroun, il n’a jamais été aussi facile de trouver la pièce qui vous correspond !</p>
                   </div>
                </div>
        </>
    )
}
 
