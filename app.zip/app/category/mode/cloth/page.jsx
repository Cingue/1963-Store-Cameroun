import ClientComponentCloth from "./clientComponentCloth";

export const metadata = {
    title: "Tenues et mode Africaine",
    description: "Stylisme/modélisme Design Confection de vetements Homme et Femme Maroquinerie Broderie",
    keywords: "Afritude, Stylisme modelisme, Modele homme, Modele femme, Boubou, Gandouras, Agbadas, Gants"
}

export default function AllClothProducts () {
    return(
        <>
        <ClientComponentCloth />

        <div className="flex flex-col item-center justify-center bg-white" style={{padding: '1rem'}}>
            <h1 className="text-justify text-lg"> <strong>Les vêtements Afritudes au Cameroun</strong> : Un Mélange de Culture, Style et Modernité</h1> <br />

            <p className="text-justify"> <strong>Les vêtements Afritudes</strong> sont bien plus qu'une simple tendance. Ils incarnent un style unique qui puise ses racines dans la richesse des cultures africaines, tout en les modernisant pour les adapter aux besoins et aux goûts contemporains. <strong>L’Afritude</strong>, ce mélange d'africanité et d'attitude urbaine, devient ainsi un véritable phénomène dans le monde de la mode.</p>

            <h2 className="text-justify text-lg">Une fusion entre tradition et modernité</h2> <br />

            <p className="text-justify">Les <strong> Afritudes </strong>ne sont pas seulement une forme d'expression vestimentaire, mais un hommage aux cultures africaines, qui se décline à travers des motifs, des couleurs vives et des textiles d’origine artisanale. <strong>Le pagne, tissu traditionnel</strong> utilisé dans de nombreuses régions d'Afrique, est l'un des matériaux les plus emblématiques de ce mouvement. Ces motifs géométriques, floraux ou animaliers sont revisités dans des coupes modernes et adaptées à la mode urbaine.</p>

            <h3 className="text-justify text-lg">Un vêtementsd'affirmation et de fierté</h3> <br />

            <p className="text-justify"> <strong>Les vêtements Afritudes</strong> portent un message de fierté culturelle, particulièrement dans un contexte où la mode occidentale a longtemps dominé. En adoptant ces tenues, les jeunes générations africaines réaffirment leur identité et leur héritage culturel avec audace et conviction. Ces vêtements sont souvent perçus comme un moyen de lutter contre l’appropriation culturelle, en revendiquant la place de la culture africaine dans le monde de la mode.</p>


        </div>
        </>
    )
}
 
