import ModelesFemmes from "./clientComponentModelesFemmes"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
    title: "Couture et Modèle Tenues Afritude Femmes",
    description: "Confectionné vos modèle et tenue Femme afritude, enfants et couple sur mesure à  douala au Cameroun",
    keywords: "Afritude, Stylisme modelisme, Modèle homme, Modèle femme, Boubou, Gandouras, Agbadas, Gants"
}

export default function AllModeleFemmes () {
    return(
        <>
        <ModelesFemmes/>

        <Link href='https://wa.me/message/E4AYZ2YLWRODC1' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </>
    )
}
 
