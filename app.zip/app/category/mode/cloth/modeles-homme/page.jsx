import ModelesHommes from "./clientComponentModelesHomme";
import Link from "next/link";
import Image from "next/image";

export const metadata = {
    title: "Couture et Modèle tenue Afritude Homme",
    description: "Confectionné vos modèle et tenue homme, enfants et couple sur mesure à  douala au Cameroun",
    keywords: "Afritude, Stylisme modelisme, Modele homme, Modele femme, Boubou, Gandouras, Agbadas, Gants"
}

export default function AllModeleFemmes () {
    return(
        <>
        <ModelesHommes/>

        <Link href='https://wa.me/message/E4AYZ2YLWRODC1' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </>
    )
}
 
