'use client'

import { clothData } from "@/app/components/Utils/clothData";
import Image from "next/image";
import Link from "next/link";
// import ModeBanner from "@/app/components/bannerCategories/mode";
import { useState } from "react";
import { useRouter } from "next/navigation";


export default function ModelesFemmes () {

    const [showCategory, setShowCategoy] = useState(true)
    const router = useRouter()
    const {modeles_femmes, modeles_homme} = clothData
    
    return(
        <>
        <Image src='/favicones/menu.svg' width={45} height={45} alt="menu" className="fixed" onClick={() => setShowCategoy(!showCategory)}/> 
        <div style={{marginLeft: showCategory ? '.5rem' : '8rem', padding: '0.8rem .3rem 1rem 2rem'}}>
        {/* <ModeBanner/> */}
        </div>
         <div className="fixed top-40 h-full left-0 flex flex-col gap-4 shadow-lg border-l border-l-gray-700 overflow-auto z-30 bg-white" style={{minWidth: '150px', paddingTop: '1.8rem', backgroundColor: 'white', paddingLeft: '.3em', display: showCategory ? 'none': 'block', lineHeight: '3rem'}}>

                <Image src='/favicones/close_icon.svg' width={25} height={25} alt="close-icone" style={{marginLeft: "7rem", marginTop: '3rem'}} onClick={() => setShowCategoy(!showCategory)}/>

                <Link href="/category/mode/montres" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/watch.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Montres</Link>

                {/* <Link href="/" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/bague.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Bagues</Link> */}

                <Link href="/category/mode/chaines"className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/bijoux.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Chaines</Link>
               
                {/* <Link href="/" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/boucle.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Boucles</Link> */}
               
                <Link href="/category/mode/manchettes" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/chaine.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Manchettes</Link>
                
                <Link href="/category/mode/cloth" className="flex items-center" style={{gap: '.5em', color: '#111184'}}> <Image src='/favicones/cloth.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Tenue Afritude</Link>
        </div>

        <div style={{padding: showCategory ? '0rem 1rem 1rem 2.8rem' : "0rem 1rem 1rem 6rem", width: '100%'}} className="gap-4 flex-flex-col items-center">

            <div className="flex flex-col items-center" style={{gap: '1rem'}}>
                <h1 className="font-bold">MODELE AFRITUDE FEMME</h1>
                <p>Quelques réalisations</p>
                <div className="category-container">
                    {modeles_femmes && modeles_femmes.map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 16)}...</p>
                            </div>
                        </Link>    
    
                            </div>
                    )).slice(0,4)}
                    </div>
                    <button style={{backgroundColor: "#111184", padding: ".3em", borderRadius: ".5em"}} className="text-white self-center" onClick={() => router.push("/category/mode/cloth/modeles-femme")}>Voir plus...</button>
            </div>

            <div className="flex flex-col items-center" style={{gap: '1rem', paddingTop: "3rem"}}>
                <h1 className="font-bold">MODELE AFRITUDE HOMMES</h1>
                <p>Quelques  réalisations</p>
                <div className="category-container">
                    {modeles_homme && modeles_homme.map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 16)}...</p>
                            </div>
                        </Link>    
    
                            </div>
                    )).slice(0,4)}
                    </div>
                    <button style={{backgroundColor: "#111184", padding: ".3em", borderRadius: ".5em"}} className="text-white self-center" onClick={() => router.push("/category/mode/cloth/modeles-homme")}>Voir plus...</button>
            </div>
        </div>

        </>
    )
}