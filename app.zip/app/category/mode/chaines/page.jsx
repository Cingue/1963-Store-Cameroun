import ClientComponentChaines from "./clientComponentChaines"

export const metadata = {
    title: "Achats chaines | Bijoux Cameroun",
    description: "Achat et vente des bijoux, chaines hommes et femmes au Cameroun. Acheter vos chaines chez 1963-store Cameroun",
    keywords: "Chaines pour femme et enfants",
}


export default function AllChainesProducts () {
    return(
        <>
        <ClientComponentChaines />
        </>
    )
}
 
