import Link from "next/link";
import Image from "next/image";
import ClientComponentDecoration from "./clientComponentDecoration";


export const metadata = {
    title: "Tableaux décoration personnalisé | décoration intérieure",
    description: 'vente et achat des beaux tableaux de décoration au Cameroun',
    keywords: "Tableau d'art, Tableau de décoration, Tableau personnalisé, Cadre photo, Tableau photo"
}

export default function AllDecorationProducts () {
    return(
        <>
        <ClientComponentDecoration/> 

        <div className="flex flex-col item-center justify-center bg-white" style={{padding: '1rem'}}>
                    <h1 className="text-justify"><strong>Décoration intérieure</strong> : Des articles pour chaque style sur <strong>1963-store.com</strong></h1> <br />

                   <div className="gap-4 flex flex-col">
                    <p className="text-justify">Sur <strong>1963-store.com,</strong> la décoration devient un jeu d'enfant ! Que vous cherchiez à donner une nouvelle vie à votre salon, à ajouter une touche de fraîcheur à votre chambre ou à embellir votre salle à manger, nous vous proposons une vaste gamme de produits décoratifs pour chaque pièce.</p>

                    <p className="text-justify">Explorez nos sous-catégories, notamment <strong>meubles </strong> (canapés, tables, étagères), <strong>textiles</strong>   (rideaux, coussins, tapis), <strong>luminaires</strong> (lampes, appliques, suspensions) et accessoires décoratifs (cadres, miroirs, horloges) et <strong>plantes artificielles</strong>. Chaque produit est sélectionné pour son design et sa qualité, vous permettant de créer une ambiance harmonieuse et chaleureuse dans chaque pièce de votre maison. Que vous soyez un amateur de <strong>design moderne, rustique, ou bohème</strong>. Sur 1963-store.com, nous avons des solutions pour tous les styles et budgets.</p>

                    <p className="text-justify">Créez un environnement qui vous ressemble grâce à nos articles de décoration, livrés partout au Cameroun.</p>

                   </div>
                   <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
                </Link>
                </div>
        </>
    )
}
 
