'use client'

import { electronicData } from "@/app/components/Utils/electronicData";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ClientComponentElectroniques () {

    const [showCategory, setShowCategoy] = useState(true)
    const router = useRouter()
    const { electroniques } = electronicData
   

    return ( 

        <>
        <Image src='/favicones/menu.svg' width={45} height={45} alt="menu" className="fixed" onClick={() => setShowCategoy(!showCategory)}/> 

        <div className="fixed top-40 h-full left-0 flex flex-col gap-4 shadow-lg border-l border-l-gray-700 overflow-auto z-10 bg-white" style={{minWidth: '150px', paddingTop: '3.5rem', backgroundColor: 'white', paddingLeft: '.3em', paddingRight: '.3rem', display: showCategory ? 'none': 'block', lineHeight: '3rem'}}>
            
                <Image src='/favicones/close_icon.svg' width={25} height={25} alt="close-icone" style={{marginLeft: "11rem", paddingTop: "2rem"}} onClick={() => setShowCategoy(!showCategory)}/>

                <Link href="/category/electroniques" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/iphone.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Telephones</Link>

                <Link href="#" className="flex items-center" style={{gap: '.5em',color: '#111184'}}> <Image src='/favicones/electronics.svg' width={21} height={21} alt="icone" style={{backgroundColor: '#111184', borderRadius: '40%'}}/>Accessoires électroniques</Link>


        </div>

        <div className="flex flex-col gap-4 w-full items-center" style={{padding: "4rem 0 3rem 0"}}>

            <h1 className="font-bold text-lg">Espace Téléphones</h1>

            <div className="aff-pro grid grid-cols-3 md:grid-cols-3 gap-4 p-4">
                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/electroniques/telephones/iphones"> <Image src="/banner/iphone.jpg" width={350} height={350} alt="iphone pub"/></Link>
                </div>

                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/electroniques/telephones/samsungs"> <Image src="/banner/samsung.jpg" width={350} height={350} alt="samsung pub"/></Link>
                </div>

                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/electroniques/telephones/samsungs"> <Image src="/banner/gpixel.jpg" width={350} height={350} alt="samsung pub"/></Link>
                </div>
                
            </div>
        </div>


        <div style={{padding: showCategory ? "3rem 1rem 1rem 1rem" : "3rem 1rem 1rem 3rem" }}>

        <div style={{padding: "0rem 1rem 1rem 1rem"}} className="flex items-center flex-col gap-4">
        <h1 className="font-bold text-lg">Accessoires électroniques</h1>
                <div className="category-container">
                    {electroniques && electroniques.map(item => (
                        <div className="div-anim" key={item.id}>
                        <Link href={`/category/${item?.category}/telephones/${item?.subCategory}/${item.path}`}>
                            <div className="flex flex-col items-center" >
                                <Image src={item.image_jpg} alt={item.description} width={400} height={100}/>
                                <p>{item.name.slice(0, 14)}...</p>
                                <p className="font-bold">{item.price.toLocaleString('en-US')} FCFA</p>
                                <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')} Fcfa</p>
                            </div>
                        </Link>    
    
                            </div>
                    )).slice(0,4)}
                </div>

                <button style={{backgroundColor: "#111184", padding: ".3em", borderRadius: ".5em"}} className="text-white self-center" onClick={() => router.push("/category/electroniques/accessoires")}>Voir plus...</button>

            </div>
            <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </div>
        </>
     );
}