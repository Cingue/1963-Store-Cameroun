import Telephones from "@/app/components/GlobalProducts/Telephones/Phones";

export const metadata = {
    title: "Boutiuque vente Smartphones Cameroun à des brix bas",
    description: "acheter vos Smartphones au Cameroun à des prix abordables neuf et seconde main chez 1963-store cameroun",
    keywords: ""
}


export default function TelephonesPage () {
    return(
        <>
        <div className="flex flex-col items-center p-4">
        <h1 className="text-lg self-center font-bold text-justify">Acheter Une collection de <strong>téléphones androïde et IOS</strong> soigneusement sélectionnés partout au Cameroun</h1>
        <Telephones padding={"1rem 0 0 0"}/>
        </div>

        <div className="flex flex-col gap-4 p-4 bg-white">
        <h1 className="text-lg font-bold">1963 store Cameroun - Votre partenaire pour <strong>acheter des smartphones</strong> de qualité supérieure</h1>

            <p className="text-justify">1963 store est votre destination incontournable pour découvrir et <strong>acheter les téléphones de qualités a des prix abordables</strong>, alliant performance et modernité. Notre <strong>boutique de téléphone</strong> a  réuni pour vous les plus grandes marques telles que <strong>IPhone, Huawei, Samsung, Tecno, Infinix, Google Pixel</strong> et bien d'autres, afin de vous offrir une sélection de téléphones adaptés à vos besoins technologiques. Que vous soyez passionné par l'innovation, la performance ou le design, vous trouverez votre bonheur parmi nos produits.</p>

            <h2 className="text-lg font-bold">Des <strong>téléphones</strong> pour chaque usage et chaque style de vie</h2>

            <p className="text-justify">Notre <strong>collection de téléphones</strong> haut de gamme d’androïde et IOS a été pensée pour répondre à toutes vos attentes. Chaque modèle de ces téléphones a été choisi pour ses caractéristiques exceptionnelles, sa rapidité d'exécution, et son interface intuitive. Que vous soyez un amateur de photographie, un gamer assidu, ou simplement en quête de simplicité et de praticité, nous avons le smartphone idéal pour vous.</p>

            <h3 className="text-lg font-bold">Un processus d' <strong>achat de téléphones</strong>simple et rapide</h3>

            <p className="text-justify">1963 store Cameroun, nous mettons un point d'honneur à rendre votre expérience d'<strong>achat fluide et agréable</strong>. Notre équipe est disponible pour répondre à vos interrogations et vous orienter vers le modèle qui correspond parfaitement à vos besoins. Vous pourrez ainsi faire votre choix en toute confiance et profiter d'une livraison rapide.</p>

            <h4 className="text-lg font-bold">Les dernières tendances en matière de technologie de téléphone à portée de clic</h4>

            <p className="text-justify">Ne cherchez plus ailleurs pour <strong>l’achat de vos téléphones</strong>. 1963 store Cameroun vous propose les dernières avancées technologiques avec des smartphones à la pointe de l'innovation. Des processeurs ultra-rapides, des écrans haute définition, des appareils photo de qualité professionnelle et des batteries ultra-performantes – tout ce dont vous avez besoin pour rester connecté et à la pointe de la technologie.</p>

            <h5 className="text-lg font-bold">Satisfaction garantie et services personnalisés</h5>

            <p className="text-justify">Nous savons que l'achat d'un téléphone est une décision importante, c’est pourquoi nous vous garantissons une qualité irréprochable et un service après-vente à la hauteur de vos attentes. Profitez de nos services personnalisés, de nos conseils d'experts, et de notre livraison rapide. Votre satisfaction est notre priorité.</p>

            <h1 className="text-lg font-bold">Trouvez le smartphone qui vous correspond chez 1963 store Cameroun</h1>

            <p className="text-justify">Venez découvrir notre large choix de <strong>téléphones IPhone, Samsung, Huwei, Infinix, Tecno, Google pixel</strong> etc. et choisissez celui qui vous accompagnera au quotidien. Que ce soit pour le travail, les loisirs ou pour rester connecté avec vos proches, nous avons ce qu’il vous faut. Nous sommes impatients de vous accueillir sur notre site et de vous offrir un service de qualité, adapté à vos besoins. </p>
        </div>
        </>
    )
}