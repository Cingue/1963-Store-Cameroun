import ClientComponentGpixel from "./clientComponentGpixel"

export const metadata = {
    title: "Acheter Téléphones Google-Pixel Cameroun à des brix bas",
    description: "acheter vos téléphones préférés Google pixel de chez Google au Cameroun à des prix abordables neuf et seconde main chez 1963-store cameroun",
    keywords: ""
}

export default function AllGpixelProducts () {
    return(
        <>
        <ClientComponentGpixel/> 
        </>
    )
}
 
