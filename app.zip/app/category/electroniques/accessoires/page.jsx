import ClientComponentAccessoires from "./clientComponentAccessoires"

export const metadata = {
    title: "Appareils électroniques | Bon prix",
    description: "",
    keywords: ""
}

export default function AllAccessoiresProducts () {
    return(
        <>
        <ClientComponentAccessoires/>
        </>
    )
}
 
