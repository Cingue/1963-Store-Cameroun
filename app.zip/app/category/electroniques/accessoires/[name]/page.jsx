import { allData } from "@/app/components/Utils/allData";
import Link from "next/link";
import Image from "next/image";
import AddToCart from "@/app/components/AddToCartButton/AddToCart";

export const generateMetadata = async ({params}) => {
    const allParams = await params
    const productId = await allParams.name

    return{
        title: productId,
        description: productId,
        keywords: null
    }
}

export default async function getSingleProduct({params}) {
  
  const allParams = (await params)
  const productId = await allParams.name
 
  const product = allData.products.find(value => value.path === productId)
  
  
        if (!product) {
        throw new Error('Ooops! Could not find the product')
      }


        return(
          <div className="p-4">

                <div className="py-8">
                <Link className="flex" href="/category/electroniques/accessoires"> <Image src="/favicones/back.svg" width={25} height={25} alt="back-icon"/> Catalogue complet ici</Link>
                </div>

          
                       <div className="grid md:grid-cols-4 md:gap-3">
          
                           <div className="md:col-span-2">
                               <Image src={product.image_jpg} alt={product.description} width={600} height={600} />
                           </div>
          
                           <div>
                               <ul>
                                   <li>
                                       <h1 className="text-lg">{product.name}</h1>
                                       <hr />

                                       <div className="flex items-center" style={{gap: ".5em"}}>

                                        <p className="text-lg font-bold self-center">Prix: </p>

                                        <p className="text-lg font-bold self-center" style={{color: "red"}}> {product.price.toLocaleString('en-US')}FCFA </p>

                                       </div>
                                   </li>

                                   <hr className="my-3"/>
          
                                   <p>Satisfait ou remboursé</p>
                               </ul>
                        

                            <hr className="my-3"/>
                    
                            <div className="flex flex-col">
                                <div className="flex items-center gap-4">
                                    <Image src="/favicones/deliveryc.svg" alt="delivery-icon" width={40} height={40} />
                                    <p className="font-bold">Livraison rapide en moins de 24h</p>
                                </div>

                                <div className="flex items-center gap-4">
                                    <Image src="/favicones/argentc.svg" alt="delivery-icon" width={40} height={40} />
                                    <p className="font-bold">Payement à la livraison</p>
                                </div>

                                <div className="flex items-center gap-4">
                                    <Image src="/favicones/garantiec.svg" alt="delivery-icon" width={40} height={40} />
                                    <p className="font-bold">Qualité garantie</p>
                                </div>
                                    </div>
          
                           <div>
                               <div className="card p-5 flex flex-col">
                                   <div className="mb-2 flex justify-between">
                                       <div>
                                           Prix
                                       </div>
                                       <div>
                                           {product.price.toLocaleString('en-US')} FCFA
                                       </div>
                                   </div>

                                </div>

                                   <AddToCart product={product} redirect={true}/>

                                   <div className="flex items-center justify-center">
                                   <a href="/cart" style={{marginTop: '1rem', padding: '.5rem', backgroundColor: 'orange', borderRadius: '.4rem'}} className="self-center">Allez au pannier</a>
                                   </div>
          
                               </div>
                           </div>
                       </div>
                       
                       <Link href='https://wa.me/237699832518' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
                    </Link>
                   </div>
   )
}

