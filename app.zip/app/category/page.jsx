import Image from "next/image";
import Link from "next/link";

export const metadata = {
    title: "Category",
    description: "",
    keywords: "" 
}


export default function AllProducts () {


    return ( 

        <div className="flex flex-col items-center p-5" style={{marginBottom: '6rem'}}>
            <h2 className="font-bold self-center text-2xl p-5 tracking-wider">Catégories</h2>

            <div className=" grid grid-cols-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 vs:grid-cols-2 gap-4 p-5 rounded-lg bg-gray-400">

                <Link href="/category/bijoux" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/bijoux.svg" alt="bijoux-icon" width={80} height={80} />Bijoux</Link>
                <Link href="/category/decoration" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/deco.svg" alt="house-icon" width={80} height={80} />Décoration</Link>
                <Link href="/category/sante" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/health.svg" alt="health-icon" width={80} height={80} />Santé</Link>
                <Link href="/category/beauty" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/beauty.svg" alt="beauty-icon" width={80} height={80} />Beauté</Link>
                <Link href="/category/electronique" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/electronics.svg" alt="electronics-icon" width={80} height={80} />Electronique</Link>
                <Link href="/category/electro-menager" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/equipment.svg" alt="equipment-icon" width={80} height={80} />Electro-Ménager</Link>
                <Link href="/category/sport" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/sport.svg" alt="sport-icon" width={80} height={80} />Sport</Link>
                <Link href="/category/cloth" className="div-anim flex flex-col items-center justify-center text-white">  <Image src="/favicones/cloth.svg" alt="health-icon" width={80} height={80} />Vestimentaire</Link>

            </div>
        </div>
     );
}