import PaymentPage from "./clientComponentPayment"

export const metadata = {
    title: "Livraison",
    description: "",
    keywords: "",
}


export default function PlaceAnOrder() {
    
    return(
        <PaymentPage />
    )
}