"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { useForm } from "react-hook-form"
import { useDispatch, useSelector } from "react-redux"
import CheckOutPage from "../components/ShippingPage/Shipping"
import { savePaymentMethod, } from "../globalRedux/features/cartSlice"



export default function PaymentPage () {
    
    const {

        handleSubmit,
        register,
        formState: { errors },
        setValue,

    } = useForm()

    const router = useRouter()
    const dispatch = useDispatch()
    const { paymentMethod, shippingAddress } = useSelector( state => state.cart)


    useEffect(() => {
        setValue('paymentMethod', paymentMethod)
    }, [setValue, shippingAddress, router, paymentMethod])


    const submitHandler = ({paymentMethod}) => {

        dispatch (
            savePaymentMethod (paymentMethod)
        )

        router.push('/placeorder')
    }



    return(

        <div style={{marginBottom: '14rem'}}>
        <CheckOutPage activeStep={1}/>

        <form
        className="mx-auto max-w-screen-md flex flex-col p-5"
        onSubmit={handleSubmit(submitHandler)}
        >

            <h1 className="mb-4 text-xl self-center"> Détails de la Livraison </h1>

            {["Livraison express (moins de 3h)", "Livraison rapide (moins de 24h)", "Livraison programée"].map((payment) => (
                <div key={payment} className="mb-4">
                    <input name="paymentMethod"
                    className="p-2 outline-none focus:ring-0"
                    id={payment}
                    type="radio"
                    value={payment}
                    {...register("paymentMethod", {
                        required: "Veuillez selctionner une méthode de payement"
                    })} 
                    />

                    <label htmlFor={payment} className="p-2">
                        {payment}
                    </label>

                </div>
            ))}

            {errors.paymentMethod && (
                <div className="text-red-500">
                    {errors.paymentMethod.message}
                </div>
            )}

            <div className="mb-4 flex justify-between">
                <button className="btn"> Next </button>
            </div>

        </form>

       
        </div>
    )
} 
