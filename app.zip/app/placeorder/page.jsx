import Placeorder from "./clientComponentPlaceOrder"


export const metadata = {
    title: "Place Order",
    description: "",
    keywords: "",
}


export default function PlaceAnOrder() {
    
    return(
        <Placeorder />
    )
}