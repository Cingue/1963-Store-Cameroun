"use client"

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import CheckOutPage from "../components/ShippingPage/Shipping";
import Link from "next/link";
import Image from "next/image";

export default function Placeorder() {

    const [result, setResult] = useState("");

    const [formValue, setFormValue] = useState(null)


    const onSubmit = async (event) => {
        event.preventDefault();
        setResult("Envoie en cours....");
        const formData = new FormData(event.target);
    
        formData.append("access_key", "addcc430-99e9-4d70-a955-9c713c015269");
    
        const response = await fetch("https://api.web3forms.com/submit", {
          method: "POST",
          body: formData
        });
    
        const data = await response.json();

        if (data.success) {
          setResult("Commande enregistrée avec success");
          event.target.reset();
         return  setTimeout(() => {
            alert('Commande enregistrée avec success.\n Nous vous recontacterons.')
                 router.push('/')
        }, 1500)

        } else {
          console.log("Error", data);
          setResult(data.message);
        }
      };

    
    const {
        products,
        shippingAddress,
        paymentMethod,
    } = useSelector(state => state.cart)
    
    const router = useRouter()
    
    useEffect(() => {
        if (!paymentMethod) {
            router.push('/payment')
        }

        else if (!shippingAddress) {
            router.push('/checkout')
        }
    }, [paymentMethod, shippingAddress, router])

    return(
        <div style={{ marginBottom: '4rem'}}>
            <CheckOutPage activeStep={3} />

            {products.lenght === 0 ? (
                <div>Votre pannier est vide . <Link href="/">Commencez vos achat</Link></div>
            ): (
                <div className="grid md:grid-cols-4 md:gap-5">
                    <div className="overflow-x-auto md:col-span-3">

                        <div className="card p-5">

                            <h2 className="mb-2 text-lg">Adresse de Livraison</h2>

                            <div className="flex flex-col itesm-center justify-centers">
                                <span>Prenom: {shippingAddress.prenom}</span>
                                <span>Ville: {shippingAddress.ville}</span>
                            </div>

                            <div>
                                <Link style={{color: '#111184'}} href="/checkout">Modifier</Link>
                            </div>

                        </div>

                        <div className="card p-5">

                            <h2 className="mb-2 text-lg">Détails de la Livraison</h2>

                            <div>{paymentMethod}</div>
                            <div>
                                <Link style={{color: '#111184'}}  href="/payment">Modifier</Link>
                            </div>
                        </div>

                        <div className="card overflow-x-auto p-5">

                            <h2 className="mb-2 text-lg">Ordered Items</h2>

                            <table className="min-w-full">
                                <thead className="border-b">

                                    <tr>
                                        <th className="px-5 text-left"> item</th>
                                        <th className="px-5 text-right"> Quantity</th>
                                        <th className="px-5 text-right"> Price</th>
                                        <th className="px-5 text-right"> Sub-total</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {products.map((item) => (
                                        <tr key={item.id}>

                                            <td>
                                                <Link
                                                href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}
                                                className="flex items-center"
                                                >

                                                    <Image src={item.image_jpg}
                                                    alt={item.description}
                                                    width={50}
                                                    height={50}
                                                    style={{
                                                        maxWidth: "100%",
                                                        height: "auto"
                                                    }}
                                                    />
                                                    {item.name}
                                                    </Link>
                                            </td>


                                            <td className="p-5 text-right"> {item.qty}</td>
                                            <td className="p-5 text-right"> {item.price.toLocaleString('en-US')}</td>
                                            <td className="p-5 text-right"> {item.price * item.qty} FCFA</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                            <div>
                                <Link style={{color: '#111184'}}  href="/cart">
                                Modifier
                                </Link>
                            </div>

                        </div>
                    </div>

                    <form onSubmit={onSubmit} className="flex flex-col items-center p-5 gap-y-2">

                        <span className="flex items-center flex-col">

                        <h2>Résumé de la commande</h2>
                        <p>Articles</p>

                        </span>

                        {products.map((item, index) => (

                        <div key={item.id}>
                            <input type="text" onChange={(e) => setFormValue(e.target.value)} value={item.name} name={index} id={item.id} />
                        </div>

                        ))}

                        <div className="flex flex-col items-center justify-center">
                            <p>Prenom</p>
                            <input type="text" name="prenom" value={shippingAddress.prenom} onChange={(e) => setFormValue(e.target.value)} />
                        </div>

                        <div className="flex flex-col items-center justify-center">
                            <p>Adresse e-mail</p>
                            <input type="email" name="email" value={shippingAddress.adresse_mail} onChange={(e) => setFormValue(e.target.value)} />
                        </div>

                        <div className="flex flex-col items-center justify-center">
                            <p>Numero de téléphone</p>
                            <input type="text" name="numero" value={shippingAddress.telephone}  onChange={(e) => setFormValue(e.target.value)} />
                        </div>

                        <div className="flex flex-col items-center justify-center">
                            <p>Ville</p>
                            <input type="text" name="Ville" value={shippingAddress.ville}  onChange={(e) => setFormValue(e.target.value)} />
                        </div>

                        <div className="flex items-center justify-center">
                            <p style={{fontSize: '.9em', color: 'red'}}>Livraison <strong>Gratuite</strong></p>
                        </div>

                        <div>
                            <input type="submit" value="Commander" name="formsend" className="btn"/>
                        </div>

                        <span>{result}</span>

                    </form>
                </div>
            )}
        </div>
    )
}
