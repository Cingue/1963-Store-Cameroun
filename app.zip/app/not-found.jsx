import Head from 'next/head';

export const metadata = {
  title: "Not Found Page",
  description: "",
  keywords: "" 
}

export default function NotFound({error}) {
    return( 

    <>
    
        <div className="flex flex-col items-center justify-center gap-4 p-4 text-4xl"  style={{minHeight: '50vh', marginBottom: '7.5rem'}}> 404 | Not Found
        </div>

        <Head>
        <title>Not found</title>
        <meta name="robots" content="NOINDEX, NOFOLLOW" key="not-found-page" /> 
      </Head>

    </>

    );
}