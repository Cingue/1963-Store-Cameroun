import { Montserrat, Lato } from "next/font/google";
import "./globals.css";
import { Providers } from "./globalRedux/provider";
import { GoogleTagManager } from '@next/third-parties/google'
import Script from "next/script"
import Link from "next/link";
import Image from "next/image";

const montserrat = Montserrat({
  weight: ['300', '400', '500', '700'],
  subsets: ['latin'],
  display:'swap',
  fallback: ['Arial', 'sans-serif'],
});

const lato = Lato({
  weight: ['300', '400',],
  subsets: ['latin'],
  display:'swap',
  fallback: ['Arial', 'sans-serif'],
});


export const metadata = {
  title: "1963-store Cameroun | Site de vente en ligne aux meilleures prix ",
  description: "Site de vente en ligne Cameroun, douala, yaounde. Vente Montres de luxe, tableau personnalisés, tableau de décoration, ensemble survêtements, produits de santé, accessoires électroniques, vêtements afritudes, maillots, montres de luxe téléphone, IPHONE, TECNO, INFINIX, GOOGLE PIXEL ",
  keywords: "accéssoires électroniques, électro-ménager, tableaux de décoration, équipements sportifs",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <head>
      <meta name="google-site-verification" content="ObUIB5jIVBLaMRO9JsA7ozBF5A6zufYhZ6VYT73gseg"/>
      <meta property="og:site_name" content="1963-store Cameroun"/>
      <meta property="product:price:currency" content="XAF"/>
      <meta property="og:url" content="https://1963-store.com"/>
      <meta property="og:locale" content="fr_FR"/>
      <meta name="robots" content="INDEX, FOLLOW" key="not-found-page" />
      
      <Script async src="https://www.googletagmanager.com/gtag/js?id=G-QMNSM0CC9D" />
      </head>
      <body
         className={`flex w-full ${montserrat.className} ${lato.className}`}
      >
         <div className="container" style={{maxWidth: '100%'}}>
        <Providers>
          {children}
        </Providers>
            <Link href="#main-nav">
              <Image src="/favicones/up.svg" alt="up" width={40} height={40}  style={{position: "fixed", top: "90%", left: "88%", zIndex: '998'}}/>
            </Link>

            {/* <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
            </Link> */}
            
        </div>
        <GoogleTagManager gtmId="GTM-TH9WKPNK" />
      </body>
    </html>
  );
}
