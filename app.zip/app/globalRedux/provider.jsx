"use client";

import { Provider } from "react-redux";
import NavBar from "../components/Navbar/NavBar";
import SideBar from "../components/Navbar/SideBar/SideBar";
import toast, { Toaster } from 'react-hot-toast';
import { persistore, store } from "./store";
import { PersistGate } from "redux-persist/integration/react";
import Footer from "../components/Footer/Footer";

export function Providers({children}) {

    return(

        <>
       
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistore}>
             <Toaster />
             <NavBar />
             <SideBar /> 
             {children}
             <Footer />
            </PersistGate>
        </Provider>


        </>
    )
}