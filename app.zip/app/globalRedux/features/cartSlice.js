"use client"

import { createSlice} from "@reduxjs/toolkit";
import toast, { Toaster } from 'react-hot-toast';

 const initialState = { 
     products:[],
     shippingAddress: {},
     paymentMethod: "",
    }

const addDecimals = (num) => {
    return num.toLocaleString('en-US')
}


const cartSlice = createSlice({
    name: "cart",
    initialState,
    reducers: {
        addToCart: (state, action) => {
            const item = action.payload
            const existItem = state.products.find((value) => value.id === item.id)

            if (existItem) {
                state.products = state.products.map((value) => value.id === existItem.id ? item : value)
            }

            else{
                state.products = [...state.products, item]
                toast.success(`${item.name} ajouté au pannier`, {position: "bottom-right"})
            }

            
            state.itemPrice = addDecimals( 
                state.products.reduce((acc, item) => acc + item?.price * item.qty, 0 )
            )
            
            state.totalPrice = addDecimals(
                Number(state.itemPrice)
            )

        },

        removeFromCart: (state, action) =>{
            state.products = state.products.filter((value) => value.id !== action.payload)
            
            state.itemPrice = addDecimals( 
                state.products.reduce((acc, item) => acc + item.price * item.qty, 0 )
            )
            
            state.totalPrice = addDecimals(
                Number(state.itemPrice)
            )
            
            toast.error( "Article retiré du pannier", {position: "top-right"})

        },

        saveShippingAddress: (state, action) => {
            state.shippingAddress = action.payload
            //ajouter local storage
        },

        savePaymentMethod: (state, action) => {
            state.paymentMethod = action.payload
            //ajouter local storage
        },

    },

})

export const {addToCart, removeFromCart, saveShippingAddress, savePaymentMethod } = cartSlice.actions
export default cartSlice.reducer