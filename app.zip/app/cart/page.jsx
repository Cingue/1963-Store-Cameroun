import Cart from "./clientComponentCart"

export const metadata = {
    title: "Cart",
    description: "",
    keywords: "",
}


export default function Carts() {
    
    return(
        <Cart/>
    )
}