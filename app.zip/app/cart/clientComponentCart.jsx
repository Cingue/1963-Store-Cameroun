"use client"

import { useRouter } from "next/navigation"
import { useDispatch, useSelector } from "react-redux"
import { addToCart, removeFromCart } from "../globalRedux/features/cartSlice"
import Link from "next/link"
import Image from "next/image"


export default function Cart () {

    const dispatch = useDispatch()
    const router = useRouter()
    const { products, itemPrice } = useSelector((state) => state.cart)


    const handleAddToCart = (product, qty) => {
        dispatch(addToCart({ ...product, qty}))
    }

    const handleRemoveFromCart = (id) => {
        dispatch(removeFromCart(id))
    }


    return(
        
        <div className="flex items-center justify-center flex-col">
            {products.length === 0 ? (
                <div className="flex flex-col items-center justify-center" style={{marginBottom: '30rem', minHeight: '35vh'}}>
                    Votre pannier est vide. <Link href="/" className="text-4xl">Start shopping</Link>
                </div>
            ) : (
                <div className="grid md:grid-cols-2 md:gap-5 justify-items-center" style={{padding: '1em', marginBottom: '12rem'}}>
                    <div className="overflow-x-auto md:col-span-3">
                        <table className="min-w-full">


                            <thead className="border-b">
                                <tr>
                                    <th className="p-5 text-left">Article</th>
                                    <th className="p-5 text-right">Quantité</th>
                                    <th className="p-5 text-right">prix</th>
                                    <th className="p-5">Delete</th>
                                </tr>
                            </thead>

                            <tbody>
                                {products.map((item) => (
                                    <tr key={item.id} className="border-b">
                                        <td>
                                            <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`} className="flex items-center">
                                            <Image src={item.image_jpg} alt={item.description} width={50} height={50}/>
                                                {item.name}
                                            </Link>
                                        </td>

                                        <td className="p-5 text-right">

                                            <select value={item.qty} onChange={(e) => handleAddToCart(item, Number(e.target.value))}>
                                                {[...Array(item.countInStock).keys()].map((value) => (
                                                    <option key={value + 1} value={value + 1 }>
                                                        {value + 1}
                                                    </option>
                                                ))}
                                            </select>

                                        </td>

                                        <td className="p-5 text-right"> {item.price.toLocaleString('en-US')} FCFA</td>
                                        <td className="p-5 text-center">
                                            <button className="defailt-button" onClick={() => handleRemoveFromCart(item.id)}>
                                               <Image src="/favicones/delete_icon.svg" alt="delte-icon" width={28} height={28}/>
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="card p-5" style={{gridColumn: '1 / -1'}}>

                        <ul>
                            <li>

                        <div className="pb-3 text-xl">
                            Sous-Total ({products.reduce((acc, value) => acc + value.qty, 0 )}) : {itemPrice} FCFA
                        </div>

                            </li>
                            <li>
                                <button onClick={() => router.push("/checkout")} className="btn">
                                    Poursuivre ma commande
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            )}
        </div>
    )
}