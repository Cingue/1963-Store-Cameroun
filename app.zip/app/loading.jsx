export default function Loading () {
    return <div className="flex flex-col items-center justify-center gap-4 p-4 text-4xl" style={{minHeight: '50vh', marginBottom: '12rem'}}> Loading... </div>
}