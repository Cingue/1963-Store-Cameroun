import ShippingPage from "./clientComponentCheckout"

export const metadata = {
    title: "Check out",
    description: "",
    keywords: "",
}


export default function CheckOut() {
    
    return(
        <ShippingPage/>
    )
}