"use client"

import { saveShippingAddress } from "@/app/globalRedux/features/cartSlice"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { useForm } from "react-hook-form"
import { useDispatch, useSelector } from "react-redux"
import CheckOutPage from "../components/ShippingPage/Shipping"


export default function ShippingPage () {
    
    const {
        handleSubmit,
        register,
        formState: { errors },
        setValue,
    } = useForm()

    const router = useRouter()
    const dispatch = useDispatch()
    const { shippingAddress } = useSelector( state => state.cart)


    useEffect(() => {
        setValue('prenom', shippingAddress.prenom)
        setValue('ville', shippingAddress.ville)
        setValue('adresse_mail', shippingAddress.adresse_mail)
        setValue('telephone', shippingAddress.telephone)
    }, [setValue, shippingAddress])


    const submitHandler = ({nom,
        prenom,
        ville,
        adresse_mail,
        telephone
    }) => {

        dispatch (
            saveShippingAddress ({prenom, ville, adresse_mail, telephone})
        )

        router.push('/payment')
    }


    return(

        <div>
        <CheckOutPage activeStep={0}/>

        <form
        className="mx-auto max-w-screen-md flex flex-col p-5"
        onSubmit={handleSubmit(submitHandler)}
        >

            <h1 className="mb-4 text-xl self-center"> Adresse de livraison</h1>

            <div className="mb-4">
                <label htmlFor="Prenom"> Prenom </label>
                <input 
                className="w-full"
                id="prenom"
                {...register('prenom', {
                    required: "Veuillez renseignez ce champ"
                })}/>

                {errors.prenom && (
                    <div className="text-red-500">
                        {errors.prenom.message}
                    </div>
                )}
            </div>

            <div className="mb-4">
                <label htmlFor="numéro de tel"> Numéro de tel </label>
                <input 
                className="w-full"
                id="numero"
                {...register('telephone', {
                    required: "Veuillez entrez un numéro valide",
                    pattern:  /^[1-9 +-][0-9 +-]{0,23}$/,
                })}/>

                {errors.telephone && (
                    <div className="text-red-500">
                        {errors.telephone.message}
                    </div>
                )}
            </div>

            <div className="mb-4">
                <label htmlFor="ville"> Ville </label>
                <input 
                className="w-full"
                id="ville"
                {...register('ville', {
                    required: "Veuillez renseignez ce champ"
                })}/>

                {errors.ville && (
                    <div className="text-red-500">
                        {errors.ville.message}
                    </div>
                )}
            </div>

            <div className="mb-4">
                <label htmlFor="Addresse e-mail"> Addresse e-mail (Facultatif) </label>
                <input 
                className="w-full"
                id="adresse_mail"
                type="email"
                {...register('adresse_mail')}/>

                {errors.adresse_mail && (
                    <div className="text-red-500">
                        {errors.adresse_mail.message}
                    </div>
                )}
            </div>

            <div className="mb-4 flex justify-between self-center">
                <button className="btn"> Next </button>
            </div>

        </form>

       
        </div>
    )
} 
