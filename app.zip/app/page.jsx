import HomePageProducts from "./components/HomePageProducts/page";

export default function Home() {

  return (
   <main className="flex flex-col gap-4 justify-center mr-auto ml-auto my-0 relative">
      <HomePageProducts/>
   </main>

  );
}
