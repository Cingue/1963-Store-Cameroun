"use client"

import Image from "next/image";
import { useState } from "react";

export default function PicturesDetails ({img1, img2, img3, img4}) {

    const [showImg1, setShowImg1] = useState(true)
    const [showImg2, setShowImg2] = useState(true)
    const [showImg3, setShowImg3] = useState(true)
    const [showImg4, setShowImg4] = useState(true)

    const [style1, setStyle1] = useState(true)
    const [style2, setStyle2] = useState(true)
    const [style3, setStyle3] = useState(true)
    const [style4, setStyle4] = useState(true)

    const displayImg1 = () => {
       setShowImg1(true); setShowImg2(false); setShowImg3(false); setShowImg4(false); setStyle1(false); setStyle2(true); setStyle3(true); setStyle4(true)
    }

    const displayImg2 = () => {
        setShowImg1(false); setShowImg2(true); setShowImg1(false); setShowImg3(false); setShowImg4(false);  setStyle1(true); setStyle2(false); setStyle3(true); setStyle4(true);
    }
    
    const displayImg3 = () => {
        setShowImg1(false); setShowImg2(false); setShowImg4(false); setShowImg3(true); setStyle1(true); setStyle2(true); setStyle3(false); setStyle4(true);
    }

    const displayImg4 = () => {
        setShowImg1(false); setShowImg2(false); setShowImg3(false); setShowImg4(true); setStyle1(true); setStyle2(true); setStyle3(true); setStyle4(false);
    }

    return ( 


        <div className="flex flex-col gap-1 items-center p-4">

            <div className="flex gap-4 items-center overflow-hidden" style={{maxWidth: "500px"}}>
                <Image src={img1} width={600} height={800} alt="montres_de_luxe" style={{display: showImg1 ? "block" : "none"}} />
                <Image src={img2} width={600} height={800} alt="montres_de_luxe" style={{display: showImg2 ? "block" : "none"}}/>
                <Image src={img3} width={600} height={800} alt="montres_de_luxe" style={{display: showImg3 ? "block" : "none"}}/>
                <Image src={img4}  width={600} height={800} alt="montres_de_luxe" style={{display: showImg4 ? "block" : "none"}}/>
            </div>

            <div className="flex items-center gap-1">

                <div style={{padding: style1 ? "0" : '.09rem', backgroundColor: style1 ? 'none' : "#111184"}}
                onClick={displayImg1}>
                <Image src={img1} width={100} height={100} alt="montres_de_luxe" />
                </div>

                <div  style={{padding: style2 ? "0" : '.09rem', backgroundColor: style2 ? 'none' : "#111184"}} 
                onClick={displayImg2}>
                <Image src={img2} width={100} height={100} alt="montres_de_luxe"/>
                </div>

                <div  style={{padding: style3 ? "0" : '.09rem', backgroundColor: style3 ? 'none' : "#111184"}}
                onClick={displayImg3}>
                <Image src={img3} width={100} height={100} alt="montres_de_luxe" />
                </div>

                <div  style={{padding: style4 ? "0" : '.09rem', backgroundColor: style4 ? 'none' : "#111184"}}
                onClick={displayImg4}>
                <Image src={img4} width={100} height={100} alt="montres_de_luxe" />
                </div>

            </div>

        </div>

    );
}