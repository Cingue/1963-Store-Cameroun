import Image from "next/image";
import Link from "next/link"; 

export default function OrderByPhone () {

    return(
        <div id="orderByPhone" className="w-full flex flex-col items-center justify-center none hidden ">
            <h2>Commandez par telephone</h2>
                <p>Service client 7j/7 :</p>
            <div id="info-c" className="grid items-center justify-items-center grid-cols-2 shadow-lg">
                <Link href='#' className="flex">  <Image src='/favicones/call.svg' width={25} height={25} alt="whatsapp-icon"/>699832515</Link>
                <Link href='https://wa.me/qr/KLBXE63QY7OEG1' target="_blank" className="flex"> <Image src='/favicones/whatsapp2.svg' width={25} height={25} alt="whatsapp-icon"/>682554278</Link>
            </div>
        </div>
    )
}