'use client'

import HeadSlider from "../HeaderSlider/HeadSlider";
import Beauty from "../ProductsSliders/Beauty/BeautyBlock";
import ClothFemme from "../ProductsSliders/ClothFemmes/page.jsx";
import ClothSliderHomme from "../ProductsSliders/ClothHommes/ClothSlider";
import ElectroMenager from "../ProductsSliders/Electro-Menager/ElectroMenagerBlock";
import Electronic from "../ProductsSliders/Electronics/ElectronicBlock";
import Sante from "../ProductsSliders/Sante/SanteBlock";
import OrderByPhone from "../OrderByPhone/OrderByPhone";
import Sport from "../ProductsSliders/Sport/SportBlock";
import Decoration from "../ProductsSliders/Decoration/DecorationBlock";
import Montres from "../ProductsSliders/montres/MontresBlock";
import Telephones from "../GlobalProducts/Telephones/Phones";

export default function ClientComponentHomepage() {
    return(
        <>
        <OrderByPhone /> 
        <HeadSlider />
        <Montres />
        <Decoration />
        <Telephones padding={"4rem 0 3rem 0"} />
        <Sport/>
        <ElectroMenager />
        <Electronic/>
        <ClothSliderHomme />
        <ClothFemme />
        <Beauty />
        <Sante />

        </>
    )
}