import { useSelector, useDispatch } from "react-redux";
import Link from "next/link";
import Image from "next/image";
import { addToCart, removeFromCart } from "@/app/globalRedux/features/cartSlice";
import { useState } from "react";


export default function SideBar ({Width = "0"}) {


    const [hideSideBar, setHideSideBar] = useState(false)

    const {products, itemPrice }= useSelector((state) => state.cart)
    const dispatch = useDispatch()

    const handleAddToCart =(product, qty) => {
        dispatch(addToCart({...product,qty}))
        
    }

    const handleHideSideBar = () => {
        setHideSideBar(!hideSideBar)
    }

    const handleRemoveFromCart = (id) => {
        dispatch(removeFromCart(id))
    }

    return(
        <div id="side-bar" className="fixed top-0 right-0 h-full flex flex-col items-center shadow-lg border-l border-l-gray-700 overflow-auto z-50 bg-white" style={{width: Width , display: hideSideBar ? "none" : "fixed"}}>

            <div className="py-5 px-2">
               {products.length === 0 ? (
                <div className="py-5 px-2">
                    Votre pannier est vide
                </div>
               ) : (
                <>
                <div className="p-2 flex flex-col items-center border-b border-b-gray-600">

                    <button id="close_button" className="flex self-end" onClick={handleHideSideBar}> <Image src="/favicones/close_icon.svg" alt="delete_icon" width={32} height={32} /> </button>

                    <div>Sous-Total</div>
                    <div className="font-bold text-orange-700"> {itemPrice} FCFA</div>

                    <div>
                        <Link href="/cart" className="w-full text-center p-1 rounded-2xl border-2">Go to Cart</Link>
                    </div>

                    {products.map((item) => (
                        <div key={item.id} className="p-2 flex-col items-center border-b border-b-gray-600">

                            <Link href={`/product/${item.id}`} className="flex items-center">

                            <Image src={item.image_jpg} alt={item.description} width={50} height={50} className="p-1" />
                            <div>
                                {item.name}
                            </div>
                            
                            </Link>

                            <select value={item.qty} onChange={(e) => handleAddToCart(item, Number(e.target.value))} >

                                {[...Array(item.countInStock).keys()].map((value) => (
                                    <option key={ value + 1 } value={ value + 1 }>
                                        {value + 1}

                                    </option>
                                ))}
                            </select>

                            <button className="default-button ml-2" onClick={() => handleRemoveFromCart(item.id)}>
                                Delete
                            </button>
                        </div>
                    ))}
                </div>
                </>
               ) }
            </div>

        </div>
    )
}