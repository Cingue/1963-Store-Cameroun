'use client'

import { useState } from "react"
import { allData } from "../../Utils/allData"
import Link from "next/link"
import Image from "next/image"

export default function Search () {

    const { products } = allData

    const [liveSearch, setLiveSearch] = useState([])
    

    const filter =(e) => {
        setLiveSearch(products.filter((value) => value.name.toLowerCase().includes(e.target.value.toLowerCase())))

        if (e.target.value.trim() === '') {
            setLiveSearch([])
        }
    }

    const handleOnBlur = (e) => {
         if (e.target) {

            setTimeout(() =>{
                setLiveSearch([])
            }, 500)
        }
    }
    

    return(
    <form id="search" className="flex flex items-center flex-col justify-center " style={{position: "relative"}}>
        <input type="search" name="" id="" placeholder="Search..." className="bg-white rounded-2xl p-2.5 outline-none w-full" onChange={filter} onBlur={handleOnBlur}/>
        <Image src='/favicones/search.svg' width={25} height={25} alt="search-icon" style={{position: 'absolute', left: '90%'}} />

        <div className="bg-white" style={{width: "100%", overflow: "auto", maxHeight:"200px", position: "absolute", top: "3rem"}}>
            {liveSearch.map((item) => (
                <div key={item.id} style={{width: "100%", height: "70px", overflow: "hidden"}}>

                    <Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`} className="flex items-center " style={{gap: '1rem'}} id="search-result">
                    <Image src={item.image_jpg} width={50} height={50} alt={item.description}/>
                    <div className=" flex flex-col">
                    <p>{item.name}</p>
                    <p>{item.price.toLocaleString('en-US')} FCFA</p>
                    <p className='line-through tracking-wider text-slate-400'>{item.reducedPrice.toLocaleString('en-US')}FCFA</p>
                    </div>
                    </Link>

                </div>
            ))}
        </div>
    </form>
    )
}