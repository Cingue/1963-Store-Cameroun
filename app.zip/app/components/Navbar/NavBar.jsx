"use client"

import { useSelector } from "react-redux";

import Link from "next/link";
import Image from "next/image";
import Search from "./SearchField/SearchField"; 

const NavBar = () => {

    const { products }= useSelector((state) => state.cart)

    return ( 

        <nav id="main-nav" className=" flex flex-col justify-center top-0 sticky fixed z-40" style={{backgroundColor: "#111184"}}>
            <div id="under-nav">
                <div className="flex flex items-center justify-center" style={{padding: ".3em"}}>

                    <Link href="/">
                        <Image src="/favicones/logo.png" alt="logo" width={95} height={95} />
                    </Link>
               </div>

                    <Search />

            <div className="flex items-center justify-center">

                <Link href="/cart" className="flex items-center justify-center">
                     <Image src="/favicones/mdi--cart-outline.svg" alt="cart-icon" width={30} height={30} />
                    

                    <span id="card-status" className="bg-red-600" style={{borderRadius: "50%", padding: "1px 5px", color: "white", fontSize: ".9em", fontFamily: 'montserrat'}}> {products.reduce((a, c) => a + c.qty, 0)} </span>

                </Link>
            </div>

            </div>

            <div className="categories-nav flex items-center justify-center overflow-auto no-scrollbar px-4" style={{width: "100%", gap: "3rem", padding: '.8rem'}} >
                <Link href="/category/mode" className="flex items-center justify-center text-white">  <Image src="/favicones/bijoux.svg" alt="bijoux-icon" width={30} height={30} />Mode</Link>
                <Link href="/category/electroniques/telephones" className="flex items-center justify-center text-white">  <Image src="/favicones/iphone.svg" alt="phone" width={30} height={30} />Telephones</Link>
                <Link href="/category/decoration" className="flex items-center justify-center text-white">  <Image src="/favicones/deco.svg" alt="house-icon" width={30} height={30} />Décoration</Link>
                <Link href="/category/sante" className="flex items-center justify-center text-white">  <Image src="/favicones/health.svg" alt="health-icon" width={30} height={30} />Santé</Link>
                <Link href="/category/beauty" className="flex items-center justify-center text-white">  <Image src="/favicones/beauty.svg" alt="beauty-icon" width={30} height={30} />Beauté</Link>
                <Link href="/category/electroniques" className="flex items-center justify-center text-white">  <Image src="/favicones/electronics.svg" alt="electronics-icon" width={30} height={30} />Electronique</Link>
                <Link href="/category/electro-menager" className="flex items-center justify-center text-white">  <Image src="/favicones/equipment.svg" alt="equipment-icon" width={30} height={30} />Electro-Ménager</Link>
                <Link href="/category/sport" className="flex items-center justify-center text-white">  <Image src="/favicones/sports.svg" alt="sport-icon" width={30} height={30} />Sport</Link>
            </div>

        </nav>
    )
}
 
export default NavBar;