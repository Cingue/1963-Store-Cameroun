export const santeData = {
    products: [
        {
             id: "601",
             name: "Madu vitamine",
             image: "/sante/madu_vitamine.webp",
             image_jpg: "/sante_jpg/madu_vitamine.jpg",
             price: 18000,
             reducedPrice: 25000,
             countInStock: 30,
             description: "Madu vitamine",
             path: "Madu_vitamine",
             category: "sante",
             subCategory: "bien-etre",
        },

        {
             id: "602",
             name: "Bonbon hercule",
             image: "/sante/bonbon_hercule.webp",
             image_jpg: "/sante_jpg/bonbon_hercule.jpg",
             price: 20000,
             reducedPrice: 25000,
             countInStock: 30,
             description: "Bonbon hercule",
             path: "Bonbon_hercule",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "603",
             name: "Ceinture Sport",
             image: "/sante/ceinture_ventre_plat.webp",
             image_jpg: "/sante_jpg/ceinture_ventre_plat.jpg",
             price: 10000,
             reducedPrice: 15000,
             countInStock: 30,
             description: "Ceinture_Sport",
             path: "Ceinture_Sport",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "604",
             name: "Kopivitamine",
             image: "/sante/kopivitamine.webp",
             image_jpg: "/sante_jpg/kopivitamine.jpg",
             price: 15000,
             reducedPrice: 25000,
             countInStock: 30,
             description: "Kopivitamine",
             path: "Kopivitamine",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "605",
             name: "Vatamax",
             image: "/sante/vitamax_rose.webp",
             image_jpg: "/sante_jpg/vitamax_rose.jpg",
             price: 18000,
             reducedPrice: 22000,
             countInStock: 30,
             description: "Vitamax",
             path: "Vitamax_",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "606",
             name: "Pistolet de massage",
             image: "/sante/pistolet_de_massage.webp",
             image_jpg: "/sante_jpg/pistolet_de_massage.jpg",
             price: 15000,
             reducedPrice: 20500,
             countInStock: 30,
             description: "Pistolet de massage",
             path: "Pistolet_de_massage",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "607",
             name: "Tensiometre",
             image: "/sante/pression_arterielle.webp",
             image_jpg: "/sante_jpg/pression_arterielle.jpg",
             price: 10000,
             reducedPrice: 12000,
             countInStock: 30,
             description: "Tensiometre",
             path: "Tensiometre",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "608",
             name: "Tapis pour Sport",
             image: "/sante/tapis_pour_sport.webp",
             image_jpg: "/sante_jpg/tapis_pour_sport.jpg",
             price: 7000,
             reducedPrice: 10000,
             countInStock: 30,
             description: "Tapis pour Sport",
             path: "Tapis_pour_sport",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "609",
             name: "Tensiometre",
             image: "/sante/tensiometre.webp",
             image_jpg: "/sante_jpg/tensiometre.jpg",
             price: 8000,
             reducedPrice: 12000,
             countInStock: 30,
             description: "Tensiometre",
             path: "Tensiometre",
             category: "sante",
             subCategory: "bien-etre"
        },

        {
             id: "610",
             name: "Vitamax",
             image: "/sante/vitamax.webp",
             image_jpg: "/sante_jpg/vitamax.jpg",
             price: 18000,
             reducedPrice: 23000,
             countInStock: 30,
             description: "vitamax",
             path: "Vitamax",
             category: "sante",
             subCategory: "bien-etre"
        },
        
        {
            id: "611",
            name: "Sirop prise de poids",
            image: "/sante/sirop_prise_de_poids_2.webp",
            image_jpg: "/sante_jpg/sirop_prise_de_poids_2.jpg",
            price: 10000,
            reducedPrice: 15000,
            countInStock: 30,
            description: "sirop prise de poids",
            path: "Sirop_prise_de_poids",
            category: "sante",
            subCategory: "bien-etre"
        },

        {
            id: "612",
            name: "Stick vaginal",
            image: "/sante/stick_vaginal.webp",
            image_jpg: "/sante_jpg/stick_vaginal.jpg",
            price: 5000,
            reducedPrice: 8000,
            countInStock: 30,
            description: "stick vaginal",
            path: "stick_vaginal",
            category: "sante",
            subCategory: "bien-etre"
        },
        
        {
            id: "613",
            name: "Pistolet de massage 4 tete",
            image: "/sante/pistolet_massage_4_tete.webp",
            image_jpg: "/sante_jpg/pistolet_massage_4_tete.jpg",
            price: 18000,
            reducedPrice: 23000,
            countInStock: 30,
            description: "Pistolet de massage 4 tete",
            path: "Pistolet_de_massage_4_tete",
            category: "sante",
            subCategory: "bien-etre"
       },
        
        {
            id: "614",
            name: "Charbon actif de coco 35g",
            image: "/sante/charbon_actif_de_coco.webp",
            image_jpg: "/sante_jpg/charbon_actif_de_coco.jpg",
            price: 1000,
            reducedPrice: 3000,
            countInStock: 30,
            description: "charbon de coco",
            path: "charbon_actif_de_coco",
            category: "sante",
            subCategory: "bien-etre"
       },
        
        {
            id: "615",
            name: "Eau de coco 1L",
            image: "/sante/eau_de_coco.webp",
            image_jpg: "/sante_jpg/eau_de_coco.jpg",
            price: 1000,
            reducedPrice: 1500,
            countInStock: 30,
            description: "eau de coco",
            path: "eau_de_coco",
            category: "sante",
            subCategory: "bien-etre"
       },

       {
            id: "616",
            name: "Sacoche imperméable",
            image: "/sante/sacoche.webp",
            image_jpg: "/sante_jpg/sacoche.jpg",
            price: 5000,
            reducedPrice: 7000,
            countInStock: 30,

            description:  {
               description1: "Protégé vos pieces personnelles contre l'eau avec nos saccoches imperméables",
               description2: "Résiste a l'eau",
               description3: "Solide, Légé",
               description4: "Disponible en Rose, Bleu, Noir",
               description5: "Satisfait ou remboursé",
               description6: "2 sacoches achetées, un parapluie offert"
            },

            path: "Sacoche-impermeable",
            category: "sante",
            subCategory: "bien-etre"
       },
    ]
}