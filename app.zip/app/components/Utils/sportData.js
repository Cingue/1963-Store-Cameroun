export const sportData = {
    survetements: [

        //Jogging data starts
        {
            id: "701",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_1.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_1.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_1",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "702",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_2.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_2.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_2",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "703",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_3.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_3.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_3",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "704",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_4.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_4.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_4",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "705",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_5.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_5.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_5",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "706",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_6.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_6.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_6",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "707",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_7.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_7.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_7",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "708",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_8.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_8.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_8",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "709",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_9.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_9.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_9",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "710",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_10.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_10.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_10",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "711",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_11.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_11.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement",
            category: "sport",
            subCategory: "survetements",
            
         },

        {
            id: "712",
            name: "Ensemble survêtement",
            image: "/sport/survet_equip/survet/jogging_12.webp",
            image_jpg: "/sport/survet_equip/survet_jpg/jogging_12.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Jogging pour sport/Ensemble survêtement",
            path: "Ensemble_survetement_12",
            category: "sport",
            subCategory: "survetements",
            
         },
        ],
          //Jogging data Ends

          
          maillots: [
            {
                id: "801",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_1.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_1.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_1",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "802",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_2.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_2.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_2",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "803",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_3.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_3.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_3",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "804",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_4.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_4.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_4",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "805",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_5.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_5.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_5",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "806",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_6.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_6.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_6",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "807",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_7.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_7.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_7",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "808",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_8.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_8.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_8",
                category: "sport",
                subCategory: "maillots",
                
             },
    
            {
                id: "809",
                name: "Ensemble maillot",
                image: "/sport/maillot_equip/maillot/maillot_9.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_9.jpg",
                price: 5000,
                reducedPrice: 7000,
                countInStock: 30,
                description: "Maillot",
                path: "maillot_9",
                category: "sport",
                subCategory: "maillots",
                
             },
          ],

          maillot_club: [
                
            {
                id: "830",
                name: "Maillot Fan Milan Ac Home",
                image: "/sport/maillot_equip/maillot/maillot_ac_milan_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_ac_milan_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Milan Ac 2025",
                path: "Maillot-Home-Milan-Ac-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "831",
                name: "Maillot Fan Milan Ac Away",
                image: "/sport/maillot_equip/maillot/maillot_ac_milan_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_ac_milan_away.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Milan Ac 2025",
                path: "Maillot-Away-Milan-Ac-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "832",
                name: "Maillot Fan Bayern Munich Home",
                image: "/sport/maillot_equip/maillot/maillot_bayern_munich_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_bayern_munich_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Bayern Munich 2025",
                path: "Maillot-Bayern-Munich-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "833",
                name: "Maillot Fan Bayern Munich Away",
                image: "/sport/maillot_equip/maillot/maillot_bayern_munich_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_bayern_munich_away.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Bayern Munich 2025",
                path: "Maillot-Bayern-Munich-away-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "834",
                name: "Maillot Fan Brighton Home",
                image: "/sport/maillot_equip/maillot/maillot_brigton_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_brigton_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Brighton 2025",
                path: "Maillot-Brighton-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "835",
                name: "Maillot Fan Dortmun Home",
                image: "/sport/maillot_equip/maillot/maillot_dortmun_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_dortmun_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Dortmun 2025",
                path: "Maillot-Dortmun-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "836",
                name: "Maillot Fan Liverpool Home",
                image:  "/sport/maillot_equip/maillot/maillot_liverpool_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_liverpool_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Liverpool 2025",
                path: "Maillot-Liverpool-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "837",
                name: "Maillot Fan Manchester City",
                image: "/sport/maillot_equip/maillot/maillot_man_city_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_man_city_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Manchester City 2025",
                path: "Maillot-Manchester-City-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "838",
                name: "Maillot Fan Manchester United Home",
                image: "/sport/maillot_equip/maillot/maillot_man_united_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_man_united_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Manchester United Home 2025",
                path: "Maillot-Manchester-United-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "839",
                name: "Maillot Fan Manchester United away",
                image: "/sport/maillot_equip/maillot/maillot_man_united_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_man_united_away.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Manchester United Away 2025",
                path: "Maillot-Manchester-United-Away-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "840",
                name: "Maillot Fan Manchester United Third",
                image: "/sport/maillot_equip/maillot/maillot_man_united_third.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_man_united_third.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Manchester United Third 2025",
                path: "Maillot-Manchester-United-Third-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "841",
                name: "Maillot Fan Newcastle Home",
                image: "/sport/maillot_equip/maillot/maillot_newcastle_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_newcastle_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Newcastle 2025",
                path: "Maillot-Newcastle-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "842",
                name: "Maillot Fan Marseille Home",
                image: "/sport/maillot_equip/maillot/maillot_om_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_om_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Marseille 2025",
                path: "Maillot-Marseille-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "843",
                name: "Maillot Fan Marseille away",
                image: "/sport/maillot_equip/maillot/maillot_om_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_om_away.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Marseille 2025",
                path: "Maillot-Marseille-away-2025",
                category: "sport",
                subCategory: "maillots",
                
             },
                
             {
                id: "844",
                name: "Maillot Fan PSG Home",
                image: "/sport/maillot_equip/maillot/maillot_psg_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_psg_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot PSG 2025",
                path: "Maillot-PSG-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

             {
                id: "845",
                name: "Maillot Fan PSG Away",
                image: "/sport/maillot_equip/maillot/maillot_psg_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_psg_away.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot PSG 2025",
                path: "Maillot-PSG-Away-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

             {
                id: "846",
                name: "Maillot Fan Real Madrid Home",
                image: "/sport/maillot_equip/maillot/maillot_real_madrid_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_real_madrid_home.jpg",
                price: 11000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Real Madrid 2025",
                path: "Maillot-Real-Madrid-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

             {
                id: "847",
                name: "Maillot Fan Real Madrid Away",
                image: "/sport/maillot_equip/maillot/maillot_real_madrid_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_real_madrid_away.jpg",
                price: 11000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Real Madrid 2025",
                path: "Maillot-Real-Madrid-Away-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

             {
                id: "848",
                name: "Maillot Fan Spurs Home",
                image: "/sport/maillot_equip/maillot/maillot_tothenham_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_tothenham_home.jpg",
                price: 10000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Real Madrid 2025",
                path: "Maillot-Spurs-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

             {
                id: "849",
                name: "Maillot Fan Barcelone Home",
                image: "/sport/maillot_equip/maillot/maillot_barcelone_home.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_barcelone_home.jpg",
                price: 11000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot RBarcelone 2025",
                path: "Maillot-Barcelone-Home-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

             {
                id: "850",
                name: "Maillot Fan Barcelone Away",
                image: "/sport/maillot_equip/maillot/maillot_barcelone_away.webp",
                image_jpg: "/sport/maillot_equip/maillot_jpg/maillot_barcelone_away.jpg",
                price: 11000,
                reducedPrice: 13000,
                countInStock: 10,
                description: "Maillot Barcelone Away2025",
                path: "Maillot-Barcelone-Away-2025",
                category: "sport",
                subCategory: "maillots",
                
             },

          ],
        }