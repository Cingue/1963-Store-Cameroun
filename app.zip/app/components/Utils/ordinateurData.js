export const ordinateurtData = {
    dell: [
        
        {
            id: "1001",
            name: "Laptop Dell Inspiron",
            image: "/laptop/dell/Laptop Dell Inspiron.webp",
            image_jpg: "/laptop_jpg/dell/Laptop Dell Inspiron.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Laptop Dell Inspiron",
            path: "Laptop_Dell_Inspiron",
            category: "laptops",
            subCategory: "dell",
            details: "Dell i5 <br/> 11eme generation  <br/> 512gb ssd, 16gb ram"
            
         },
    ]
}