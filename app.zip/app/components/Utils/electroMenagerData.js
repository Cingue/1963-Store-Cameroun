export const electroMenagerData = {
    cuisine: [
         {
            id: "101",
            name: "Moulinex crest 3 en 1",
            image: "/electro_menager/Blender_silver_crest_3_en_1.webp",
            image_jpg: "/electro_menager_jpg/Blender_silver_crest_3_en_1.jpg",
            price: 25000,
            reducedPrice: 29000,
            countInStock: 30,
            description: "robot-mixeur",
            path: "Blender_Silver_crest_3_en_1",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "102",
            name: "Broyeur à sec électrique",
            image: "/electro_menager/Broyeur_domestique_Commercial_broyeur_à_sec_électrique.webp",
            image_jpg: "/electro_menager_jpg/Broyeur_domestique_Commercial_broyeur_à_sec_électrique.jpg",
            price: 25000,
            reducedPrice: 30000,
            countInStock: 30,
            description: "machine a écraser",
            path: "Broyeur_domestique_Commercial_broyeur_a_sec_electrique",
            category: "electro-menager",
            subCategory: "cuisine",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "103",
            name: "Chauffe Eau électrique",
            image: "/electro_menager/chauffe_eau.webp",
            image_jpg: "/electro_menager_jpg/chauffe_eau.jpg",
            price: 10000,
            reducedPrice: 16000,
            countInStock: 30,
            description: "chauffe eau",
            path: "Chauffe_eau",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "104",
            name: "Fer  à repasser électrique",
            image: "/electro_menager/fer_a_repasser.webp",
            image_jpg: "/electro_menager_jpg/fer_a_repasser.jpg",
            price: 10000,
            reducedPrice: 13000,
            countInStock: 30,
            description: "Fer a repasser",
            path: "Electric_steam_iron_R1200",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "105",
            name: "Micro-Onde Electrique",
            image: "/electro_menager/electric_oven.webp",
            image_jpg: "/electro_menager_jpg/electric_oven.jpg",
            price: 30000,
            reducedPrice: 45000,
            countInStock: 30,
            description: "Micro-onde",
            path: "Micro_onde_electrique",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "106",
            name: "Electric Skewers R8619",
            image: "/electro_menager/electric_skewers_R8619.webp",
            image_jpg: "/electro_menager_jpg/electric_skewers_R8619.jpg",
            price: 30000,
            reducedPrice: 45000,
            countInStock: 0,
            description: "Electric Skewers R8619",
            path: "Electric_Skewers_R8619",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "107",
            name: "Extracteur de Jus",
            image: "/electro_menager/extracteur_de_jus.webp",
            image_jpg: "/electro_menager_jpg/extracteur_de_jus.jpg",
            price: 38000,
            reducedPrice: 45000,
            countInStock: 30,
            description: "Extracteur de jus",
            path: "Extracteur_de_Jus",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "108",
            name: "Extracteur de Jus RAF",
            image: "/electro_menager/extracteur_de_jus_2.webp",
            image_jpg: "/electro_menager_jpg/extracteur_de_jus_2.jpg",
            price: 38000,
            reducedPrice: 45000,
            countInStock: 30,
            description: "Extracteur de jus",
            path: "Extracteur_de_Jus_2",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "109",
            name: "Extracteur de Jus",
            image: "/electro_menager/extracteur_de_jus_3.webp",
            image_jpg: "/electro_menager_jpg/extracteur_de_jus_3.jpg",
            price: 25000,
            reducedPrice: 36000,
            countInStock: 30,
            description: "Extracteur de jus",
            path: "Extracteur_de_Jus_3",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "110",
            name: "Hand Mixer",
            image: "/electro_menager/hand_mixer.webp",
            image_jpg: "/electro_menager_jpg/hand_mixer.jpg",
            price: 35000,
            reducedPrice: 45000,
            countInStock: 30,
            description: "hand-mixer",
            path: "Hand_Mixer",
            category: "electro-menager",
            subCategory: "cuisine",
            

         },

         {
            id: "111",
            name: "Moulinex RAF",
            image: "/electro_menager/moulinex_raf.webp",
            image_jpg: "/electro_menager_jpg/moulinex_raf.jpg",
            price: 38000,
            reducedPrice: 46000,
            countInStock: 30,
            description: "Moulinex",
            path: "Moulinex_raf",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "112",
            name: "Hachoir légume",
            image: "/electro_menager/vegetable_cutter_stainless_steel_panel.webp",
            image_jpg: "/electro_menager_jpg/vegetable_cutter_stainless_steel_panel.jpg",
            price: 12000,
            reducedPrice: 18000,
            countInStock: 30,
            description: "vegetable_cutter_stainless_steel_panel",
            path: "Hachoir_legume",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "113",
            name: "RAF meat grinder",
            image: "/electro_menager/RAF_Meat_Grinder_2000W_Stainless_Steel_Blades.webp",
            image_jpg: "/electro_menager_jpg/RAF_Meat_Grinder_2000W_Stainless_Steel_Blades.png",
            price: 33000,
            reducedPrice: 40000,
            countInStock: 30,
            description: "RAF_Meat_Grinder_2000W_Stainless_Steel_Blades",
            path: "Raf_meat_grinder",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "114",
            name: "Sceleuse plastique electrique",
            image: "/electro_menager/vacum_sealer_home_automatic_machine.webp",
            image_jpg: "/electro_menager_jpg/vacum_sealer_home_automatic_machine.jpg",
            price: 10000,
            reducedPrice: 13000,
            countInStock: 30,
            description: "Sceleuse plastique electrique",
            path: "Sceleuse_plastique_electrique",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         
         {
            id: "115",
            name: "Rice cooker",
            image: "/electro_menager/silver_rice_cooker.webp",
            image_jpg: "/electro_menager_jpg/silver_rice_cooker.jpg",
            price: 30000,
            reducedPrice: 45000,
            countInStock: 0,
            description: "Rice cooker",
            path: "Rice_cooker",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

         {
            id: "116",
            name: "Air fryer",
            image: "/electro_menager/air_fryer.webp",
            image_jpg: "/electro_menager_jpg/air_fryer.jpg",
            price: 30000,
            reducedPrice: 45000,
            countInStock: 0,
            description: "Air fryer",
            path: "Air_fryer",
            category: "electro-menager",
            subCategory: "cuisine",
            
         },

    ]
}