export const bijouxData = {
    montres: [
         {
            id: "401",
            name: "Rolex Célébration Bleu",
            image: "/bijoux/rolex_9.webp",
            image_jpg: "/bijoux_jpg/rolex_9.jpg",
            image2: "/bijoux_jpg/rolex_9.jpg",
            image3: "/bijoux_jpg/rolex_9.jpg",
            image4: "/bijoux_jpg/rolex_9.jpg",
            price: 10900,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Montre Rolex",
            path: "Montre_Rolex_Celebration_Bleu",
            category: "mode",
            subCategory: "montres",
            details:
            {
               description1: "Matière en Acier inoxydable",
               description2: "Bracelet solide, confortable et réglable",
               description3: "Résiste à  l'eau",
               description4: "Piles durables",
               description5: "Garantie 12 mois sur la pile et le mécanisme"
            }
         },

         {
            id: "402",
            name: "Rolex célébration jaune",
            image: "/bijoux/rolex_8.webp",
            image_jpg: "/bijoux_jpg/rolex_8.jpg",
            image2: "/bijoux_jpg/rolex_8.jpg",
            image3: "/bijoux_jpg/rolex_8.jpg",
            image4: "/bijoux_jpg/rolex_8.jpg",
            price: 10900,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Montre Rolex",
            path:"Celebration_Jaune",
            category: "mode",
            subCategory: "montres",
            details:
            {
               description1: "Matière en Acier inoxydable",
               description2: "Bracelet solide, confortable et réglable",
               description3: "Résiste à  l'eau",
               description4: "Piles durables",
               description5: "Garantie 12 mois sur la pile et le mécanisme"
            }
         }, 

         {
            id: "403",
            name: "Rolex Daytona Rainbow Gold",
            image: "/bijoux/rolex_7.webp",
            image_jpg: "/bijoux_jpg/rolex_7.jpg",
            image2: "/bijoux_jpg/rolex_7.jpg",
            image3: "/bijoux_jpg/rolex_7.jpg",
            image4: "/bijoux_jpg/rolex_7.jpg",
            price: 70000,
            reducedPrice: 90000,
            countInStock: 30,
            description: "Rolex Daytona Rainbow",
            path:"Rolex_Daytona_Rainbow",
            category: "mode",
            subCategory: "montres",
            details:
            {
               description1: "Matière en Acier inoxydable",
               description2: "Bracelet solide, confortable et réglable",
               description3: "Résiste à  l'eau",
               description4: "Piles durables",
               description5: "Affiche l'heure et la date",
               description6: "Garantie 12 mois sur la pile et le mécanisme"
            }
         },

         {
            id: "404",
            name: "Rolex Daytona Rainbow Silver",
            image: "/bijoux/rolex_6.webp",
            image_jpg: "/bijoux_jpg/rolex_6.jpg",
            image2: "/bijoux_jpg/rolex_6.jpg",
            image3: "/bijoux_jpg/rolex_6.jpg",
            image4: "/bijoux_jpg/rolex_6.jpg",
            price: 70000,
            reducedPrice: 90000,
            countInStock: 30,
            description: "Rolex Daytona Rainbow Silver",
            path:"Rolex_Daytona_Rainbow_Silver",
            category: "mode",
            subCategory: "montres",
            details:
            {
               description1: "Matière en Acier inoxydable",
               description2: "Bracelet solide, confortable et réglable",
               description3: "Résiste à  l'eau",
               description4: "Piles durables",
               description5: "Affiche l'heure et la date",
               description6: "Garantie 12 mois sur la pile et le mécanisme"
            }
         },

         {
            id: "405",
            name: "Cartier Bracelet Noir",
            image: "/bijoux/rolex_5.webp",
            image_jpg: "/bijoux_jpg/rolex_5.jpg",
            image2: "/bijoux_jpg/rolex_5.jpg",
            image3: "/bijoux_jpg/rolex_5.jpg",
            image4: "/bijoux_jpg/rolex_5.jpg",
            price: 9900,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Montre Cartier",
            path:"Cartier_santos_dumont",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
             id: "406",
             name: "Cartier Bracelet Rouge",
             image: "/bijoux/cartier_bracelet_rouge.webp",
             image_jpg: "/bijoux_jpg/cartier_bracelet_rouge.jpg",
             image2: "/bijoux_jpg/cartier_bracelet_rouge.jpg",
             image3: "/bijoux_jpg/cartier_bracelet_rouge.jpg",
             image4: "/bijoux_jpg/cartier_bracelet_rouge.jpg",
             price: 9900,
             reducedPrice: 20000,
             countInStock: 30,
             description: "Montre Cartier",
             path:"Montre-Cartier-Bracelet-Rouge",
             category: "mode",
             subCategory: "montres",
             details:
          {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
             id: "407",
             name: "Cartier Bracelet Marron",
             image: "/bijoux/cartier_bracelet_marron.webp",
             image_jpg: "/bijoux_jpg/cartier_bracelet_marron.jpg",
             image2: "/bijoux_jpg/cartier_bracelet_marron.jpg",
             image3: "/bijoux_jpg/cartier_bracelet_marron.jpg",
             image4: "/bijoux_jpg/cartier_bracelet_marron.jpg",
             price: 9900,
             reducedPrice: 20000,
             countInStock: 30,
             description: "Montre Cartier",
             path:"Montre-Cartier-Bracelet-Marron",
             category: "mode",
             subCategory: "montres",
             details:
          {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
             id: "408",
             name: "Cartier Bracelet Bleu",
             image: "/bijoux/cartier_bracelet_bleu.webp",
             image_jpg: "/bijoux_jpg/cartier_bracelet_bleu.jpg",
             image2: "/bijoux_jpg/cartier_bracelet_bleu.jpg",
             image3: "/bijoux_jpg/cartier_bracelet_bleu.jpg",
             image4: "/bijoux_jpg/cartier_bracelet_bleu.jpg",
             price: 9900,
             reducedPrice: 20000,
             countInStock: 30,
             description: "Montre Cartier",
             path:"Montre-Cartier-Bracelet-Bleu",
             category: "mode",
             subCategory: "montres",
             details:
          {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
             id: "409",
             name: "Cartier Fond Noir",
             image: "/bijoux/cartier_fond_noir.webp",
             image_jpg: "/bijoux_jpg/cartier_fond_noir.jpg",
             image2: "/bijoux_jpg/cartier_fond_noir.jpg",
             image3: "/bijoux_jpg/cartier_fond_noir.jpg",
             image4: "/bijoux_jpg/cartier_fond_noir.jpg",
             price: 9900,
             reducedPrice: 20000,
             countInStock: 30,
             description: "Montre Cartier",
             path:"Montre-Cartier-Fond-Noir",
             category: "mode",
             subCategory: "montres",
             details:
          {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
             id: "410",
             name: "Cartier Or",
             image: "/bijoux/cartier_bracelet_noir_or.webp",
             image_jpg: "/bijoux_jpg/cartier_bracelet_noir_or.jpg",
             image2: "/bijoux_jpg/cartier_bracelet_noir_or.jpg",
             image3: "/bijoux_jpg/cartier_bracelet_noir_or.jpg",
             image4: "/bijoux_jpg/cartier_bracelet_noir_or.jpg",
             price: 9900,
             reducedPrice: 20000,
             countInStock: 30,
             description: "Montre Cartier",
             path: "Montre-Cartier-Or",
             category: "mode",
             subCategory: "montres",
             details:
          {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "411",
            name: "Rolex oyster 41",
            image: "/bijoux/rolex_3.webp",
            image_jpg: "/bijoux_jpg/rolex_3.jpg",
            image2: "/bijoux_jpg/rolex_3.jpg",
            image3: "/bijoux_jpg/rolex_3.jpg",
            image4: "/bijoux_jpg/rolex_3.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Rolex oyster 41",
            path:"Rolex_oyster_41",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Matière en Acier inoxydable",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         }, 

         {
            id: "412",
            name: "Rolex tiffany",
            image: "/bijoux/rolex_2.webp",
            image_jpg: "/bijoux_jpg/rolex_2.jpg",
            image2: "/bijoux_jpg/rolex_2.jpg",
            image3: "/bijoux_jpg/rolex_2.jpg",
            image4: "/bijoux_jpg/rolex_2.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Rolex tiffany",
            path:"Rolex_tiffany",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Matière en Acier inoxydable",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "413",
            name: "Rolex oyster 36",
            image: "/bijoux/rolex.webp",
            image_jpg: "/bijoux_jpg/rolex.jpg",
            image2: "/bijoux_jpg/rolex.jpg",
            image3: "/bijoux_jpg/rolex.jpg",
            image4: "/bijoux_jpg/rolex.jpg",
            price: 15000,
            reducedPrice: 20000,
            countInStock: 30,
            description: "Rolex oyster 36",
            path:"Rolex_oyster_36",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Matière en Acier inoxydable",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "414",
            name: "Movado calendoplan",
            image: "/bijoux/movado.webp",
            image_jpg: "/bijoux_jpg/movado.jpg",
            image2: "/bijoux_jpg/movado.jpg",
            image3: "/bijoux_jpg/movado.jpg",
            image4: "/bijoux_jpg/movado.jpg",
            price: 10000,
            reducedPrice: 13000,
            countInStock: 30,
            description: "Movado calendoplan",
            path:"Movado_calendoplan",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "415",
            name: "Audemars Piquet Silver",
            image: "/bijoux/montre_4.webp",
            image_jpg: "/bijoux_jpg/montre_4.jpg",
            image2: "/bijoux_jpg/montre_4.jpg",
            image3: "/bijoux_jpg/montre_4.jpg",
            image4: "/bijoux_jpg/montre_4.jpg",
            price: 15000,
            reducedPrice: 23000,
            countInStock: 30,
            description: "Audemars Piquet",
            path:"Audemars_Piquet_Silver",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Matière en Acier inoxydable",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

          {
             id: "416",
             name: "Rolex célébration rose",
             image: "/bijoux/rolex_rose.webp",
             image_jpg: "/bijoux_jpg/rolex_rose.jpg",
             image2: "/bijoux_jpg/rolex_rose.jpg",
             image3: "/bijoux_jpg/rolex_rose.jpg",
             image4: "/bijoux_jpg/rolex_rose.jpg",
             price: 10900,
             reducedPrice: 20000,
             countInStock: 30,
             description: "rolex_rose",
             path:"rolex-rose",
             category: "mode",
             subCategory: "montres",
             details:
             {
                description1: "Matière en Acier inoxydable",
                description2: "Bracelet solide, confortable et réglable",
                description3: "Résiste à  l'eau",
                description4: "Piles durables",
                description5: "Garantie 12 mois sur la pile et le mécanisme"
             }
          },

         {
            id: "417",
            name: "Fossil",
            image: "/bijoux/montre_2.webp",
            image_jpg: "/bijoux_jpg/montre_2.jpg",
            image2: "/bijoux_jpg/montre_2.jpg",
            image3: "/bijoux_jpg/montre_2.jpg",
            image4: "/bijoux_jpg/montre_2.jpg",
            price: 20000,
            reducedPrice: 28000,
            countInStock: 30,
            description: "Montre de luxe Fossil",
            path:"Fossil",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Matière en Acier inoxydable",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "418",
            name: "Audemars Piquet Gold",
            image: "/bijoux/montre.webp",
            image_jpg: "/bijoux_jpg/montre.jpg",
            image2: "/bijoux_jpg/montre.jpg",
            image3: "/bijoux_jpg/montre.jpg",
            image4: "/bijoux_jpg/montre.jpg",
            price: 15000,
            reducedPrice: 23000,
            countInStock: 30,
            description: "Audemars Piquet Gold",
            path:"Audemars_Piquet_Gold",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Matière en Acier inoxydable",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "419",
            name: "MTP Casio",
            image: "/bijoux/casio.webp",
            image_jpg: "/bijoux_jpg/casio.jpg",
            image2: "/bijoux_jpg/casio.jpg",
            image3: "/bijoux_jpg/casio.jpg",
            image4: "/bijoux_jpg/casio.jpg",
            price: 9900,
            reducedPrice: 12000,
            countInStock: 30,
            description: "Montre casio",
            path:"MTP_casio_Vert",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "420",
            name: "MTP Casio",
            image: "/bijoux/casio_2.webp",
            image_jpg: "/bijoux_jpg/casio_2.jpg",
            image2: "/bijoux_jpg/casio_2.jpg",
            image3: "/bijoux_jpg/casio_2.jpg",
            image4: "/bijoux_jpg/casio_2.jpg",
            price: 9900,
            reducedPrice: 12000,
            countInStock: 30,
            description: "Montre casio",
            path:"MTP_casio_Marron",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "Bracelet en cuir",
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "421",
            name: "Rolex sky dweller fond_noir",
            image: null,
            image_jpg: "/bijoux_jpg/rolex_sky_dweller_fond_noir.jpg",
            image2: "/bijoux_jpg/rolex_sky_dweller_fond_noir.jpg",
            image3: "/bijoux_jpg/rolex_sky_dweller_fond_noir.jpg",
            image4: "/bijoux_jpg/rolex_sky_dweller_fond_noir.jpg",
            price: 9900,
            reducedPrice: 12000,
            countInStock: 30,
            description: "Montre rolex_sky_dweller_fond_noir",
            path:"Rolex-sky-dweller-fond-noir",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "422",
            name: "Rolex sky dweller fond noir or",
            image: null,
            image_jpg: "/bijoux_jpg/rolex_sky_dweller_fond_noir_or.jpg",
            image2: "/bijoux_jpg/rolex_sky_dweller_fond_noir_or.jpg",
            image3: "/bijoux_jpg/rolex_sky_dweller_fond_noir_or.jpg",
            image4: "/bijoux_jpg/rolex_sky_dweller_fond_noir_or.jpg",
            price: 9900,
            reducedPrice: 12000,
            countInStock: 30,
            description: "Montre rolex_sky_dweller_fond_noir_or",
            path:"Rolex-sky-dweller-fond-noir-or",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "423",
            name: "Rolex sky dweller fond or",
            image: null,
            image_jpg: "/bijoux_jpg/rolex_sky_dweller_fond_or.jpg",
            image2: "/bijoux_jpg/rolex_sky_dweller_fond_or.jpg",
            image3: "/bijoux_jpg/rolex_sky_dweller_fond_or.jpg",
            image4: "/bijoux_jpg/rolex_sky_dweller_fond_or.jpg",
            price: 9900,
            reducedPrice: 12000,
            countInStock: 30,
            description: "Montre rolex_sky_dweller_fond_noir_or",
            path:"Rolex-sky-dweller-fond-or",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "424",
            name: "Patek Philippe Fond Blanc",
            image: null,
            image_jpg: "/bijoux_jpg/patek_philippe_blanc.jpg",
            image2: "/bijoux_jpg/patek_philippe_blanc.jpg",
            image3: "/bijoux_jpg/patek_philippe_blanc.jpg",
            image4: "/bijoux_jpg/patek_philippe_blanc.jpg",
            price: 20000,
            reducedPrice: 28000,
            countInStock: 30,
            description: "Montre patek_philippe",
            path:"Patek-Philippe-Fond-Blanc",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "425",
            name: "Patek Philippe Fond Bleu",
            image: null,
            image_jpg: "/bijoux_jpg/patek_philippe_bleu.jpg",
            image2: "/bijoux_jpg/patek_philippe_bleu.jpg",
            image3: "/bijoux_jpg/patek_philippe_bleu.jpg",
            image4: "/bijoux_jpg/patek_philippe_bleu.jpg",
            price: 20000,
            reducedPrice: 28000,
            countInStock: 30,
            description: "Montre patek_philippe",
            path:"Patek-Philippe-Fond-Bleu",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "426",
            name: "Patek Philippe Fond Bleu Sombre",
            image: null,
            image_jpg: "/bijoux_jpg/patek_philippe_bleu_sombre.jpg",
            image2: "/bijoux_jpg/patek_philippe_bleu_sombre.jpg",
            image3: "/bijoux_jpg/patek_philippe_bleu_sombre.jpg",
            image4: "/bijoux_jpg/patek_philippe_bleu_sombre.jpg",
            price: 20000,
            reducedPrice: 28000,
            countInStock: 30,
            description: "Montre patek_philippe",
            path:"Patek-Philippe-Fond-Bleu-Sombre",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "427",
            name: "Patek Philippe Fond Noir",
            image: null,
            image_jpg: "/bijoux_jpg/patek_philippe_noir.jpg",
            image2: "/bijoux_jpg/patek_philippe_noir.jpg",
            image3: "/bijoux_jpg/patek_philippe_noir.jpg",
            image4: "/bijoux_jpg/patek_philippe_noir.jpg",
            price: 20000,
            reducedPrice: 28000,
            countInStock: 30,
            description: "Montre patek_philippe",
            path:"Patek-Philippe-Fond-Noir",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "428",
            name: "Patek Philippe Fond Vert",
            image: null,
            image_jpg: "/bijoux_jpg/patek_philippe_vert.jpg",
            image2: "/bijoux_jpg/patek_philippe_vert.jpg",
            image3: "/bijoux_jpg/patek_philippe_vert.jpg",
            image4: "/bijoux_jpg/patek_philippe_vert.jpg",
            price: 20000,
            reducedPrice: 28000,
            countInStock: 30,
            description: "Montre patek_philippe",
            path:"Patek-Philippe-Fond-Vert",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: null,
            description2: "Bracelet solide, confortable et réglable",
            description3: "Résiste à  l'eau",
            description4: "Piles durables",
            description5: "Affiche l'heure et la date",
            description6: "Garantie 12 mois sur la pile et le mécanisme"
         }
         },

         {
            id: "429",
            name: "Cartier Tank",
            image: null,
            image_jpg: "/bijoux_jpg/petit_cartier_1.jpg",
            image2: "/bijoux_jpg/petit_cartier_2.jpg",
            image3: "/bijoux_jpg/petit_cartier_3.jpg",
            image4: "/bijoux_jpg/petit_cartier_4.jpg",
            price: 25000,
            reducedPrice: 31000,
            countInStock: 30,
            description: "Montre Mini cartier carré",
            path:"Cartier-Tank",
            category: "mode",
            subCategory: "montres",
            details:
         {
            description1: "✓ Edition Cartier",
            description2: "✓ Bracelet solide, confortable et réglable",
            description3: "✓ Résiste à l'eau",
            description4: "✓ Piles durables",
            description5: "✓ Cadran en acier inoxydable",
            description6: "✓ Disponible en bracelet noir, vert, rouge, marron",
            description7: "✓ Garantie 90 jours sur la pile et le mécanisme",
         }
         },

         // {
         //    id: "421",
         //    name: "Coffret bijoux femme",
         //    image: "/bijoux/bijoux_5.webp",
         //    image_jpg: "/bijoux_jpg/bijoux_5.jpg",
         //    price: 20000,
         //    reducedPrice: 25000,
         //    countInStock: 30,
         //    description: "Coffret_bijoux_femme",
         //    path:"Coffret_bijoux_femme_rouge",
         //    category: "mode",
         //    subCategory: "montres",
         // },
        ],

        manchettes: [
         {
            id: "445",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_argent.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_argent.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_argent",
            category: "mode",
            subCategory: "manchettes", 
         },

         {
            id: "446",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_argent_dur.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_argent_dur.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_argent_dur",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "447",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_argent_red.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_argent_red.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_argent_red",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "448",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_blanc.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_blanc.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_blanc",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "449",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_bleu.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_bleu.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_bleu",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "450",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_cube.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_cube.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_cube",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "451",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_gris.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_gris.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_gris",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "452",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_noir.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_noir.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_noir",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "453",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_orange.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_orange.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_orange",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "454",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_rouge.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_rouge.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_rouge",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "455",
            name: "Manchettes chemise",
            image: "/manchette/manchette_cartier_vert.webp",
            image_jpg: "/manchette_jpg/manchette_cartier_vert.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_cartier_vert",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "456",
            name: "Manchettes chemise",
            image: "/manchette/manchette_louis_vuitton_argent.webp",
            image_jpg: "/manchette_jpg/manchette_louis_vuitton_argent.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_louis_vuitton_argent",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "457",
            name: "Manchettes chemise",
            image: "/manchette/manchette_louis_vuitton_bronze.webp",
            image_jpg: "/manchette_jpg/manchette_louis_vuitton_bronze.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_louis_vuitton_bronze",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "458",
            name: "Manchettes chemise",
            image: "/manchette/manchette_louis_vuitton_or.webp",
            image_jpg: "/manchette_jpg/manchette_louis_vuitton_or.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_louis_vuitton_or",
            category: "mode",
            subCategory: "manchettes",
         },

         {
            id: "459",
            name: "Manchettes chemise",
            image: "/manchette/manchette_versace_or.webp",
            image_jpg: "/manchette_jpg/manchette_versace_or.jpg",
            price: 7500,
            reducedPrice: 9500,
            countInStock: 30,
            description: "Manchette pour chemise homme/femme",
            path:"manchette_versace_or",
            category: "mode",
            subCategory: "manchettes",
         },
        ],


        chaines: [

         {
            id: "480",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_4.webp",
            image_jpg: "/chaines_jpg/bijoux_4.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_clair",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "481",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_5.webp",
            image_jpg: "/chaines_jpg/bijoux_5.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_rouge",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "482",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_6.webp",
            image_jpg: "/chaines_jpg/bijoux_6.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_rose",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "483",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_7.webp",
            image_jpg: "/chaines_jpg/bijoux_7.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_noir",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "484",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_8.webp",
            image_jpg: "/chaines_jpg/bijoux_8.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_blanc",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "485",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_1.webp",
            image_jpg: "/chaines_jpg/bijoux_1.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_vert",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "486",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_2.webp",
            image_jpg: "/chaines_jpg/bijoux_2.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_berge",
            category: "mode",
            subCategory: "chaines",
         },

         {
            id: "487",
            name: "Coffret bijoux femme",
            image: "/chaines/bijoux_3.webp",
            image_jpg: "/chaines_jpg/bijoux_3.jpg",
            price: 20000,
            reducedPrice: 25000,
            countInStock: 30,
            description: "Coffret_bijoux_femme",
            path:"Coffret_bijoux_femme_bleu",
            category: "mode",
            subCategory: "chaines",
         },

        ],
    }