"use client"

import Link from "next/link";
import MainSlider from "./Slider";
import Image from "next/image";
import SideSlider from "./SideSlider";

const HeadSlider = () => {
    return ( 
        <div className="flex flex-col ">
        <div id="main-up-slide">
            
            <div id="side-slide1" className="products-category flex flex-col bg-white rounded p-5" style={{height: "100%", gap: "1rem"}}>
                <Link href="/category/mode">Mode</Link>
                <Link href="/category/decoration">Decoration</Link>
                <Link href="/category/electroniques/telephones">Telephones</Link>
                <Link href="/category/beauty">Beauté</Link>
                <Link href="/category/electroniques">Electronique</Link>
                <Link href="/category/sante">Santé</Link>
                <Link href="/category/sport">Sport</Link>
                <Link href="/category/electro-menager">Electro-ménager</Link>
            </div>

            <div className="slider2">
                <MainSlider />
            </div>

            <div id="side-slide2" className="products-category flex flex-col items-center justify-center bg-white rounded p-5" style={{height: "100%"}}>
                <div className="w-full">
                    <SideSlider />
                </div>
            </div>
        </div>

        <div className="voiture grid grid-cols-4 rounde w-full gap-4 p-5">
            <div className=" flex items-center justify-center gap-2 bg-white p-5" style={{backgroundColor: "#111184"}}>
                <Image src="/favicones/delivery.svg" alt="delivery-icon" width={40} height={40} />
                <p style={{color: '#ffdf00'}}>Livraison rapide</p>
            </div>

            <div className=" flex items-center justify-center gap-2 bg-white p-5" style={{backgroundColor: '#ffdf00'}}>
                <Image src="/favicones/argent.svg" alt="delivery-icon" width={40} height={40} />
                <p>Payement Flexible</p>
            </div>

            <div className=" flex items-center justify-center gap-2 bg-white p-5"  style={{backgroundColor: "#111184"}}>
                <Image src="/favicones/garantie.svg" alt="delivery-icon" width={40} height={40} />
                <p style={{color: '#ffdf00'}}>Achat sous garantie</p>
            </div>

            <div className=" flex items-center justify-center gap-2 bg-white p-5" style={{backgroundColor: '#ffdf00'}}>
                <Image src="/favicones/certified.svg" alt="delivery-icon" width={40} height={40} />
                <p>Produits de qualité</p>
            </div>
        </div>
        </div>
     );
}
 
export default HeadSlider;