"use client"

// import Swiper core and required modules
import { Navigation, Pagination, Scrollbar, A11y, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import Link from "next/link";
import Image from 'next/image';


// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import "swiper/css/bundle"

const SideSlider = () => {
    return ( 
        <Swiper
        // install Swiper modules
        modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
        spaceBetween={0}
        slidesPerView={1}
        autoplay= {true}
        speed={600}
        pagination={{ clickable: true }}
      >
        <SwiperSlide><div className="swiper-slide"><Link href="/category/decoration/Tableau_2"> <Image src="/decoration_jpg/tableau_2.jpg" alt='Promo banner' width={200} height={200} /> </Link></div></SwiperSlide>

        <SwiperSlide><div className="swiper-slide"><Link href="/category/decoration/Tableau_4"> <Image src="/decoration_jpg/tableau_4.jpg" alt='Promo banner' width={200} height={200}/> </Link></div></SwiperSlide>
      </Swiper>
     );
}
 
export default SideSlider;