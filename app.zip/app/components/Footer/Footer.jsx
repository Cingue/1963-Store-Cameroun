import Link from "next/link";
import Image from "next/image";

export default function Footer () {
    return (
        <footer className="flex flex-col items-center justify-center p-4 w-full" style={{backgroundColor: "#111184"}}>
            <div className="flex flex-col">
                <div className="flex items-center justify-center gap-2" >
                     <Link href='https://www.facebook.com/profile.php?id=61573038601721' target="_blank"> <Image src='/favicones/facebook.svg' width={35} height={35} alt="facebook-tag" /> </Link>

                    <Link href='https://wa.me/message/BC6DO2EVCHY4D1' target="_blank"> <Image src='/favicones/whatsapp.svg' width={35} height={35} alt="facebook-tag" /> </Link>

                    {/* <Link href='/'> <Image src='/favicones/tiktok.svg' width={35} height={35} alt="facebook-tag" /> </Link> */}
                </div>

                <div className="flex items-center justify-center flex-wrap gap-2">
                <p className="text-white">&copy; 2025 by 1963-store Cameroun |</p>
                <p className="text-white">Site de vente en ligne</p>
                </div>

                <div className="flex items-center justify-center flex-wrap gap-2">
                <p className="text-white">Designed and Powered by</p>
                <Link href='https://wa.me/qr/KLBXE63QY7OEG1' target="_blank" style={{color: 'gray'}}>Vanold Cingue</Link>
                </div>
            </div>
        </footer>
    )
}