import ClothSliderFemme from "./ClothSlider";

export default function Cloth ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <ClothSliderFemme />
        </div>
     );
}
