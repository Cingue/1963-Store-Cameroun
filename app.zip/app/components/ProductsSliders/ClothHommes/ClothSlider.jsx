"use client"
// import Swiper core and required modules
import { Navigation, Pagination, Scrollbar, A11y, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import Link from "next/link";
import { clothData } from '@/app/components/Utils/clothData';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import "swiper/css/bundle"


export default function ClothSliderHomme ()  {

  const { modeles_homme } = clothData

  const shuffledArray = (array) => {
    for (let i = array.length -1; i > 0; i-- ) {
      const j = Math.floor(Math.random() * (i + 1))
      const temp = array[i]
      array[i] =  array[j]
      array[j] = temp
    }

    return array
  };


    return ( 
      <div className='flex flex-col' style={{gap: "1em"}}>

        <div className='flex items-center justify-between bg-white p-4 rounded'>

          <h1 className='text-2xl font-bold'>
            Couture Homme
          </h1>

          <Link href="/category/mode/cloth/modeles-homme" className='self-end ' style={{backgroundColor: "orange", borderRadius: "7px", padding: ".4em"}}>
            Voir plus...
          </Link>

        </div>

      <div>
            <>
              <Swiper
              // install Swiper modules
              modules={[Navigation, Scrollbar, A11y, Autoplay]}
              spaceBetween={1}
              slidesPerView={6}
              speed={300}
              autoplay= {true}
              pagination={{ clickable: true }}

              breakpoints={{
                200: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                300: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                500: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                640: {
                  slidesPerView: 4,
                  spaceBetween: 20,
                },
                768: {
                  slidesPerView: 4,
                  spaceBetween: 10,
                },
                1024: {
                  slidesPerView: 7,
                  spaceBetween: 1,
                },
              }}
              
            >

              {shuffledArray(modeles_homme).map((item) => (
                <SwiperSlide key={item.id}><div className="swiper-slide"><Link href={`/category/${item?.category}/${item?.subCategory}/${item.path}`}> <img src={item.image_jpg} alt={item.description}/></Link> <span className='flex flex-col items-center'><p className='tracking-wider'> {item.name}</p> </span> </div> </SwiperSlide>
              )).slice(0, 10)}
              </Swiper>
            </>
            

      </div>

    </div>
     );
}