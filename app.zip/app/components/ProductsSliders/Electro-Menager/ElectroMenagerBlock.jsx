"use client"

import ElectroMenagerSlider from "./ElectroMenagerSlider";

export default function ElectroMenager ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <ElectroMenagerSlider />
        </div>
     );
}
