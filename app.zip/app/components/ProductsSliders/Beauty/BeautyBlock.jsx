import BeautySlider from "./BeautySlider";

export default function Beauty ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <BeautySlider />
        </div>
     );
}
