import SportSlider from "./SportSlider";


export default function Sport ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <SportSlider />
        </div>
     );
}
