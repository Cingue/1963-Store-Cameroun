import DecorationSlider from "./DecorationSlider";

export default function Decoration ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <DecorationSlider />
        </div>
     );
}
