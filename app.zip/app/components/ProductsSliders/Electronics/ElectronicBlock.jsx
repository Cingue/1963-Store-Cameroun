import ElectronicSlider from "./ElectronicSlider";

export default function Electronic ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <ElectronicSlider />
        </div>
     );
}
