"use client"

import HealthSlider from "./SanteSlider";


export default function Sante ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <HealthSlider />
        </div>
     );
}
