import MontresSlider from "./MontresSlider";

export default function Montres ()  {
    return ( 
        <div className="flex flex-col item-center justify-center p-2">
            <MontresSlider />
        </div>
     );
}
