import Image from "next/image";
import Link from "next/link";

export default function Telephones({padding}) {
    return(
        <>
        <div className="flex flex-col gap-4 w-full items-center" style={{padding: padding}}>
            <div className="aff-pro grid grid-cols-3 md:grid-cols-3 gap-4 p-4">
                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/electroniques/telephones/iphones"> <Image src="/banner/iphone.jpg" width={400} height={400} alt="iphone pub"/></Link>
                </div>

                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/electroniques/telephones/samsungs"> <Image src="/banner/samsung.jpg" width={400} height={400} alt="samsung pub"/></Link>
                </div>
                
                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/electroniques/telephones/google-pixel"> <Image src="/banner/gpixel.jpg" width={400} height={400} alt="iphone pub"/></Link>
                </div>
            </div>

            <Link href='https://wa.me/237699832515' target="_blank" className="whtasapp-redirect">
              <Image src="/favicones/whatsapp3.svg" alt="up" width={40} height={40} style={{position: "fixed", top: "81%", left: "88%", zIndex: '998'}}/>
        </Link>
        </div>
        </>
    )
}