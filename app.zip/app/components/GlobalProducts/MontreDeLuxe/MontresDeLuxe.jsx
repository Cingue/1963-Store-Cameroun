import Image from "next/image";
import Link from "next/link";

export default function MontreDeLuxe({padding}) {
    return(
        <>
        <div className="flex flex-col gap-4 w-full items-center" style={{padding: padding}}>
            <div className="aff-pro grid grid-cols-3 md:grid-cols-3 gap-4 p-8">
                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/mode/montres/montres-haut-de-gamme/audemar"> <Image src="/banner/audemars.jpg" width={400} height={400} alt="audemars"/></Link>
                </div>

                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/mode/montres/montres-haut-de-gamme/cartier"> <Image src="/banner/cartier.jpg" width={400} height={400} alt="cartier"/></Link>
                </div>
                
                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/mode/montres/montres-haut-de-gamme/breitling"> <Image src="/banner/breitling.jpg" width={400} height={400} alt="breitling"/></Link>
                </div>

                <div className="div-anim overflow-hidden rounded-xl">
                    <Link href="/category/mode/montres/montres-haut-de-gamme/emporio"> <Image src="/banner/emporio_armani.jpg" width={400} height={400} alt="breitling"/></Link>
                </div>
            </div>
        </div>
        </>
    )
}