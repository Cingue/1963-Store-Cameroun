"use client"

// import Swiper core and required modules
import { Navigation, Pagination, Scrollbar, A11y, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import Link from "next/link";


// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import "swiper/css/bundle"
import Image from 'next/image';

const ModeBanner = () => {
    return ( 
        <Swiper
        // install Swiper modules
        modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
        spaceBetween={1}
        slidesPerView={1}
        autoplay= {true}
        pagination={{ clickable: true }}
      >
        <SwiperSlide><div className="swiper-slide w-full"><Link href="/products/Cartier_santos_dumont"> <img src="/banner/promo2.webp" alt='Promo banner' style={{width: "100%", height: "100%"}}/> </Link></div></SwiperSlide>

        <SwiperSlide><div className="swiper-slide w-full"><Link href="/products/Parfum_mousuf"> <img src="/banner/parfum.webp" alt='Promo banner' style={{width: "100%", height: "100%"}}/> </Link></div></SwiperSlide>
      </Swiper>
     );
}
 
export default ModeBanner;